import unittest
import time
from quantum_lattice.pruning.pruner import RecursivePruner, NodeState

class TestRecursivePruner(unittest.TestCase):
    def setUp(self):
        self.pruner = RecursivePruner(
            similarity_threshold=0.7,
            min_efficiency_gain=0.1,
            pruning_depth=1
        )
    
    def test_similarity_calculation(self):
        """Test similarity calculation between nodes."""
        node_a = NodeState(
            node_id="node_a",
            load=0.5,
            latency=50.0,
            error_rate=2.0,
            throughput=100.0
        )
        
        node_b = NodeState(
            node_id="node_b",
            load=0.55,
            latency=55.0,
            error_rate=2.2,
            throughput=105.0
        )
        
        similarity = self.pruner._calculate_similarity(node_a, node_b)
        self.assertGreaterEqual(similarity, 0.7)
        self.assertLessEqual(similarity, 1.0)
    
    def test_very_different_nodes(self):
        """Test similarity calculation for very different nodes."""
        node_a = NodeState(
            node_id="node_a",
            load=0.1,
            latency=10.0,
            error_rate=0.1,
            throughput=900.0
        )
        
        node_b = NodeState(
            node_id="node_b",
            load=0.9,
            latency=200.0,
            error_rate=10.0,
            throughput=50.0
        )
        
        similarity = self.pruner._calculate_similarity(node_a, node_b)
        self.assertLess(similarity, 0.5)
    
    def test_evaluate_pruning_candidate(self):
        """Test pruning candidate evaluation."""
        # High efficiency node
        node_a = NodeState(
            node_id="node_a",
            load=0.2,
            latency=20.0,
            error_rate=0.5,
            throughput=800.0
        )
        
        # Low efficiency node
        node_b = NodeState(
            node_id="node_b",
            load=0.8,
            latency=150.0,
            error_rate=5.0,
            throughput=200.0
        )
        
        should_prune, action, gain = self.pruner.evaluate_pruning_candidate(node_a, node_b)
        self.assertTrue(should_prune)
        self.assertGreater(gain, 0.1)
    
    def test_identical_nodes(self):
        """Test that very similar nodes trigger pruning."""
        node_a = NodeState(
            node_id="node_a",
            load=0.5,
            latency=50.0,
            error_rate=2.0,
            throughput=100.0
        )
        
        node_b = NodeState(
            node_id="node_b",
            load=0.51,
            latency=51.0,
            error_rate=2.1,
            throughput=101.0
        )
        
        # Should find them similar and recommend pruning
        pruning_action = self.pruner.prune_pair(node_a, node_b)
        self.assertIsNotNone(pruning_action)
        self.assertIn('from_node', pruning_action)
        self.assertIn('to_node', pruning_action)
        self.assertIn('efficiency_gain', pruning_action)
    
    def test_prune_node(self):
        """Test pruning a single node."""
        node_a = NodeState(
            node_id="node_a",
            load=0.8,
            latency=150.0,
            error_rate=5.0,
            throughput=200.0
        )
        
        node_b = NodeState(
            node_id="node_b",
            load=0.2,
            latency=20.0,
            error_rate=0.5,
            throughput=800.0
        )
        
        node_metrics = {
            "node_a": node_a,
            "node_b": node_b
        }
        
        # Try to prune node_a (inefficient)
        pruning_action = self.pruner.prune_node("node_a", node_metrics)
        self.assertIsNotNone(pruning_action)
        self.assertEqual(pruning_action['from_node'], "node_a")
        self.assertEqual(pruning_action['to_node'], "node_b")
    
    def test_prune_system(self):
        """Test the full pruning system."""
        nodes = {
            "node_1": NodeState("node_1", load=0.2, latency=20, error_rate=0.5, throughput=800),
            "node_2": NodeState("node_2", load=0.25, latency=22, error_rate=0.6, throughput=790),
            "node_3": NodeState("node_3", load=0.9, latency=200, error_rate=5.0, throughput=100)
        }
        
        pruning_actions = self.pruner.prune_system(nodes)
        self.assertGreater(len(pruning_actions), 0)
        
        # Check that the high load node is targeted for pruning
        from_nodes = [action['from_node'] for action in pruning_actions]
        self.assertIn("node_3", from_nodes)
    
    def test_pruning_history(self):
        """Test that pruning actions are recorded in history."""
        nodes = {
            "node_1": NodeState("node_1", load=0.2, latency=20, error_rate=0.5, throughput=800),
            "node_2": NodeState("node_2", load=0.25, latency=22, error_rate=0.6, throughput=790)
        }
        
        initial_count = len(self.pruner.pruning_history)
        self.pruner.prune_system(nodes)
        
        self.assertGreater(len(self.pruner.pruning_history), initial_count)

if __name__ == '__main__':
    unittest.main()