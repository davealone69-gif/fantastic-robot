"""Recursive Pruning Layer for Quantum Lattice."""

__version__ = "0.1.0"