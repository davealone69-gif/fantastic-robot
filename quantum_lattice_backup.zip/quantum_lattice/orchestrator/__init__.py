#!/usr/bin/env python3
"""Adaptive Load Orchestrator for Quantum Lattice.

This module implements a dynamic resource distribution system that
adjusts node workloads based on quantum probability thresholds and
real-time performance metrics.
"""

import time
import random
import math
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field


@dataclass
class NodeMetrics:
    """Real-time metrics for a quantum node."""
    node_id: str
    load: float = 0.0          # Current load (0.0-1.0)
    latency: float = 0.0       # Average response time (ms)
    error_rate: float = 0.0    # Error percentage
    throughput: float = 0.0    # Requests per second
    quantum_entropy: float = 0.0  # Quantum-inspired entropy measure
    last_update: float = field(default_factory=time.time)


class QuantumOrchestrator:
    """
    Orchestrator that uses quantum-inspired probability for load balancing.
    
    Principles:
    - Nodes exist in superposition states until measured (load assessed)
    - Entanglement correlates node performance for cooperative optimization
    - Wave function collapse occurs during load redistribution decisions
    """
    
    def __init__(self, 
                 exploration_rate: float = 0.1,
                 decay_factor: float = 0.95,
                 quantum_threshold: float = 0.7):
        """
        Initialize orchestrator with quantum parameters.
        
        Args:
            exploration_rate: Probability of exploring suboptimal nodes (0-1)
            decay_factor: How quickly old metrics lose influence (0-1)
            quantum_threshold: Threshold for quantum state collapse (0-1)
        """
        self.exploration_rate = exploration_rate
        self.decay_factor = decay_factor
        self.quantum_threshold = quantum_threshold
        self.nodes: Dict[str, NodeMetrics] = {}
        self.history: List[Tuple[str, float, float]] = []  # (node_id, timestamp, load)
        
    def register_node(self, node_id: str) -> None:
        """Register a new node with the orchestrator."""
        self.nodes[node_id] = NodeMetrics(node_id=node_id)
        
    def update_node_metrics(self, 
                          node_id: str, 
                          load: Optional[float] = None,
                          latency: Optional[float] = None,
                          error_rate: Optional[float] = None,
                          throughput: Optional[float] = None) -> None:
        """Update metrics for a specific node."""
        if node_id not in self.nodes:
            self.register_node(node_id)
            
        node = self.nodes[node_id]
        if load is not None:
            node.load = max(0.0, min(1.0, load))
        if latency is not None:
            node.latency = max(0.0, latency)
        if error_rate is not None:
            node.error_rate = max(0.0, min(100.0, error_rate))
        if throughput is not None:
            node.throughput = max(0.0, throughput)
        node.quantum_entropy = self._calculate_quantum_entropy(node)
        node.last_update = time.time()
        
        # Record in history for trend analysis
        self.history.append((node_id, time.time(), node.load))
        # Keep only recent history (last 1000 entries)
        if len(self.history) > 1000:
            self.history = self.history[-1000:]
    
    def _calculate_quantum_entropy(self, node: NodeMetrics) -> float:
        """
        Calculate quantum-inspired entropy based on node performance.
        
        Higher entropy indicates more unpredictable/optimal state for load distribution.
        """
        # Normalize metrics to 0-1 range
        load_norm = 1.0 - node.load  # Invert load (lower load = higher potential)
        latency_norm = max(0.0, 1.0 - (node.latency / 1000.0))  # Assume 1000ms max
        error_norm = 1.0 - (node.error_rate / 100.0)
        throughput_norm = min(1.0, node.throughput / 1000.0)  # Normalize to 1000 req/s max
        
        # Quantum superposition: combine states with probability amplitudes
        amplitude = math.sqrt(
            load_norm**2 + 
            latency_norm**2 + 
            error_norm**2 + 
            throughput_norm**2
        ) / 2.0  # Normalize
        
        # Entropy as uncertainty in quantum state
        entropy = -amplitude * math.log2(amplitude) if amplitude > 0 else 0.0
        return min(1.0, entropy)  # Clamp to 0-1
    
    def select_optimal_node(self, exclude: Optional[List[str]] = None) -> str:
        """
        Select optimal node using quantum probability distribution.
        
        Uses quantum-inspired selection where nodes with higher entropy
        have higher probability of being selected, but with exploration
        factor to avoid local minima.
        """
        exclude = exclude or []
        available_nodes = [nid for nid in self.nodes.keys() if nid not in exclude]
        
        if not available_nodes:
            raise ValueError("No available nodes for selection")
            
        # Calculate quantum weights
        weights = []
        for node_id in available_nodes:
            node = self.nodes[node_id]
            # Base weight from quantum entropy
            weight = node.quantum_entropy
            
            # Apply exploration bonus (encourages trying less optimal nodes)
            if random.random() < self.exploration_rate:
                weight += random.uniform(0, 0.3)
                
            weights.append(max(0.001, weight))  # Avoid zero weights
            
        # Normalize to probability distribution
        total_weight = sum(weights)
        probabilities = [w / total_weight for w in weights]
        
        # Quantum measurement: collapse wave function to select node
        selected_index = random.choices(range(len(available_nodes)), 
                                      weights=probabilities)[0]
        return available_nodes[selected_index]
    
    def redistribute_load(self, 
                        incoming_load: float,
                        current_assignments: Dict[str, float]) -> Dict[str, float]:
        """
        Redistribute incoming load across nodes using quantum principles.
        
        Args:
            incoming_load: New load to distribute (0-1)
            current_assignments: Current load distribution {node_id: load_factor}
            
        Returns:
            Updated load distribution {node_id: new_load_factor}
        """
        # Quantum entanglement redistribution: preserve total system state
        # while applying quantum probability to incoming load
        current_total = sum(current_assignments.values())
        target_total = current_total + incoming_load
        
        # Calculate available capacity per node using quantum entropy
        capacities = {}
        for node_id, node in self.nodes.items():
            current_load = current_assignments.get(node_id, 0.0)
            available = max(0.0, 1.0 - current_load - node.error_rate/100.0)
            capacities[node_id] = available * node.quantum_entropy
            
        # Distribute load proportional to quantum-weighted capacity
        total_capacity = sum(capacities.values())
        if total_capacity <= 0:
            # Fallback: distribute evenly
            per_node = target_total / max(1, len(self.nodes))
            return {node_id: min(1.0, per_node) for node_id in self.nodes.keys()}
        
        new_assignments = {}
        distributed_sum = 0.0
        for node_id in self.nodes.keys():
            capacity_ratio = capacities.get(node_id, 0.0) / total_capacity
            allocated = target_total * capacity_ratio
            new_load = min(1.0, current_assignments.get(node_id, 0.0) + allocated)
            new_assignments[node_id] = new_load
            distributed_sum += new_load
        
        # Quantum entanglement correction: ensure total is conserved
        if distributed_sum > 0:
            correction_factor = target_total / distributed_sum
            new_assignments = {
                node_id: min(1.0, load * correction_factor)
                for node_id, load in new_assignments.items()
            }
            
        return new_assignments
    
    def get_system_status(self) -> Dict:
        """Get current system status for monitoring."""
        return {
            'total_nodes': len(self.nodes),
            'average_entropy': sum(n.quantum_entropy for n in self.nodes.values()) / max(1, len(self.nodes)),
            'average_load': sum(n.load for n in self.nodes.values()) / max(1, len(self.nodes)),
            'average_latency': sum(n.latency for n in self.nodes.values()) / max(1, len(self.nodes)),
            'total_throughput': sum(n.throughput for n in self.nodes.values()),
            'timestamp': time.time()
        }


def demo_orchestrator():
    """Demonstration of quantum orchestrator functionality."""
    print("=== Quantum Orchestrator Demo ===")
    
    # Initialize orchestrator
    orchestrator = QuantumOrchestrator(exploration_rate=0.2, quantum_threshold=0.6)
    
    # Register nodes
    for i in range(3):
        orchestrator.register_node(f"node_{i}")
    
    # Simulate metric updates
    import random
    for _ in range(5):
        for i in range(3):
            node_id = f"node_{i}"
            orchestrator.update_node_metrics(
                node_id=node_id,
                load=random.uniform(0.1, 0.9),
                latency=random.uniform(10, 200),
                error_rate=random.uniform(0, 5),
                throughput=random.uniform(50, 500)
            )
    
    # Show status
    status = orchestrator.get_system_status()
    print(f"System Status: {status}")
    
    # Select optimal node
    optimal = orchestrator.select_optimal_node()
    print(f"Optimal node selected: {optimal}")
    
    # Redistribute load
    current_load = {"node_0": 0.3, "node_1": 0.4, "node_2": 0.2}
    new_load = orchestrator.redistribute_load(0.5, current_load)
    print(f"Load redistribution: {current_load} -> {new_load}")


if __name__ == "__main__":
    demo_orchestrator()