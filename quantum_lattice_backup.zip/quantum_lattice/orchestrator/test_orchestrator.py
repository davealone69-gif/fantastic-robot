import unittest
import time
from ..orchestrator import QuantumOrchestrator, NodeMetrics

class TestQuantumOrchestrator(unittest.TestCase):
    def setUp(self):
        self.orchestrator = QuantumOrchestrator(
            exploration_rate=0.1,
            decay_factor=0.9,
            quantum_threshold=0.7
        )
    
    def test_node_registration(self):
        """Test that nodes can be registered properly."""
        self.orchestrator.register_node("test_node")
        self.assertIn("test_node", self.orchestrator.nodes)
        self.assertEqual(self.orchestrator.nodes["test_node"].node_id, "test_node")
    
    def test_metrics_update(self):
        """Test updating node metrics."""
        self.orchestrator.register_node("test_node")
        self.orchestrator.update_node_metrics(
            node_id="test_node",
            load=0.5,
            latency=50.0,
            error_rate=2.0,
            throughput=100.0
        )
        
        node = self.orchestrator.nodes["test_node"]
        self.assertEqual(node.load, 0.5)
        self.assertEqual(node.latency, 50.0)
        self.assertEqual(node.error_rate, 2.0)
        self.assertEqual(node.throughput, 100.0)
        self.assertGreaterEqual(node.quantum_entropy, 0.0)
        self.assertLessEqual(node.quantum_entropy, 1.0)
    
    def test_quantum_entropy_calculation(self):
        """Test that quantum entropy is calculated correctly."""
        self.orchestrator.register_node("test_node")
        # Test with ideal values
        self.orchestrator.update_node_metrics(
            node_id="test_node",
            load=0.0,      # No load
            latency=0.0,   # No latency
            error_rate=0.0, # No errors
            throughput=1000.0 # Max throughput
        )
        entropy = self.orchestrator.nodes["test_node"].quantum_entropy
        self.assertGreaterEqual(entropy, 0.0)
        self.assertLessEqual(entropy, 1.0)
    
    def test_node_selection(self):
        """Test that node selection works."""
        # Register multiple nodes
        for i in range(3):
            self.orchestrator.register_node(f"node_{i}")
        
        # Update with different performance levels
        self.orchestrator.update_node_metrics("node_0", load=0.9, latency=100)
        self.orchestrator.update_node_metrics("node_1", load=0.1, latency=10)
        self.orchestrator.update_node_metrics("node_2", load=0.5, latency=50)
        
        # Select optimal node multiple times - should favor better nodes
        selections = []
        for _ in range(20):
            selected = self.orchestrator.select_optimal_node()
            selections.append(selected)
        
        # Node 1 should be selected most often (best performance)
        node1_count = selections.count("node_1")
        self.assertGreater(node1_count, 5)  # Should be selected reasonably often
    
    def test_load_redistribution(self):
        """Test load redistribution algorithm."""
        # Register nodes
        for i in range(3):
            self.orchestrator.register_node(f"node_{i}")
        
        # Set some initial conditions
        self.orchestrator.update_node_metrics("node_0", load=0.3, error_rate=1.0)
        self.orchestrator.update_node_metrics("node_1", load=0.4, error_rate=1.0)
        self.orchestrator.update_node_metrics("node_2", load=0.2, error_rate=1.0)
        
        current_load = {"node_0": 0.3, "node_1": 0.4, "node_2": 0.2}
        new_load = self.orchestrator.redistribute_load(0.3, current_load)
        
        # Check that total load is conserved (approximately)
        original_total = sum(current_load.values()) + 0.3
        new_total = sum(new_load.values())
        self.assertAlmostEqual(new_total, original_total, places=2)
        
        # Check that no node exceeds capacity 1.0
        for load in new_load.values():
            self.assertLessEqual(load, 1.0)
    
    def test_system_status(self):
        """Test system status reporting."""
        self.orchestrator.register_node("node_0")
        self.orchestrator.update_node_metrics("node_0", load=0.5, latency=50, throughput=100)
        
        status = self.orchestrator.get_system_status()
        self.assertEqual(status['total_nodes'], 1)
        self.assertGreaterEqual(status['average_load'], 0.0)
        self.assertLessEqual(status['average_load'], 1.0)
        self.assertIn('timestamp', status)

if __name__ == '__main__':
    unittest.main()