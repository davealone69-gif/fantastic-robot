import unittest
from .hash import quantum_hash, Node
import random
import os


class TestQuantumNode(unittest.TestCase):
    def test_quantum_hash_output_length(self):
        """SHAKE-256 should produce 32-byte output"""
        test_data = b'Hello World'
        hashed = quantum_hash(test_data)
        self.assertEqual(len(hashed), 32, "Hash length should be 32 bytes")

    def test_node_basic_functionality(self):
        """Node should process data and stay within size constraints"""
        n = Node()
        data = os.urandom(1024)
        result = n.process_data(data)
        # Result should be bytes and not equal input unless error occurred
        self.assertIsInstance(result, bytes)
        self.assertNotEqual(len(result), 0, "Output should not be empty")

    def test_self_configure_structure(self):
        """Self configuration should return proper dict structure"""
        n = Node()
        cfg = n.config
        self.assertIsInstance(cfg, dict)
        self.assertIn('NodeSettings', cfg)
        self.assertIn('hash_entropy', cfg)


if __name__ == '__main__':
    unittest.main()