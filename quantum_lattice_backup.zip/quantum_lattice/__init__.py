# Quantum Lattice Framework
# Main entry point and shared utilities for self-healing quantum architecture