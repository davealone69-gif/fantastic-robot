import sqlite3
import os

class IndexedStore:
    def __init__(self, db_path="/root/srp_app_builder/store/code_index.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS fragments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol_name TEXT,
                    description TEXT,
                    code TEXT,
                    dependencies TEXT,
                    original_repo TEXT,
                    file_path TEXT
                )
            ''')
            conn.execute('''
                CREATE TABLE IF NOT EXISTS symbol_graph (
                    parent_id INTEGER,
                    child_id INTEGER,
                    relation_type TEXT,
                    FOREIGN KEY(parent_id) REFERENCES fragments(id),
                    FOREIGN KEY(child_id) REFERENCES fragments(id)
                )
            ''')
            conn.commit()

    def add_fragment(self, symbol_name, description, code, dependencies, original_repo, file_path):
        if isinstance(dependencies, list):
            dependencies_str = ",".join(dependencies)
        else:
            dependencies_str = dependencies
            
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO fragments (symbol_name, description, code, dependencies, original_repo, file_path)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (symbol_name, description, code, dependencies_str, original_repo, file_path))
            
            fragment_id = cursor.lastrowid
            
            if dependencies and isinstance(dependencies, list):
                for dep_name in dependencies:
                    cursor.execute('SELECT id FROM fragments WHERE symbol_name = ?', (dep_name,))
                    row = cursor.fetchone()
                    if row:
                        child_id = row[0]
                        cursor.execute('''
                            INSERT OR IGNORE INTO symbol_graph (parent_id, child_id, relation_type)
                            VALUES (?, ?, ?)
                        ''', (fragment_id, child_id, 'depends_on'))
            
            conn.commit()

    def get_dependencies(self, fragment_id):
        dependencies = set()
        stack = [fragment_id]
        
        with sqlite3.connect(self.db_path) as conn:
            while stack:
                current_id = stack.pop()
                cursor = conn.execute('SELECT child_id FROM symbol_graph WHERE parent_id = ?', (current_id,))
                for row in cursor.fetchall():
                    child_id = row[0]
                    if child_id not in dependencies:
                        dependencies.add(child_id)
                        stack.append(child_id)
        return list(dependencies)

    def search(self, query):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute('''
                SELECT * FROM fragments 
                WHERE description LIKE ? OR symbol_name LIKE ?
            ''', (f'%{query}%', f'%{query}%'))
            return cursor.fetchall()

    def get_fragment(self, fragment_id):
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute('SELECT * FROM fragments WHERE id = ?', (fragment_id,))
            return cursor.fetchone()
