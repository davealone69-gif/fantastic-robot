import ast
import os
from pathlib import Path

class ASTSplitter:
    def __init__(self, output_dir="/sdcard/srp_app_builder/fragments"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def analyze_and_split(self, repo_path):
        fragments = []
        for root, _, files in os.walk(repo_path):
            for file in files:
                if file.endswith(".py"):
                    file_path = Path(root) / file
                    fragments.extend(self._process_file(file_path))
        return fragments

    def _process_file(self, file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
            try:
                tree = ast.parse(source)
            except SyntaxError:
                return []

        imports = []
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                imports.append(ast.get_source_segment(source, node))
        
        import_block = "\n".join(imports) + "\n\n"
        file_fragments = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                deps = self._extract_dependencies(node)
                fragment = self._extract_node(node, file_path, source, import_block, deps)
                file_fragments.append(fragment)
            elif isinstance(node, ast.FunctionDef) and not self._is_inside_class(node, tree):
                deps = self._extract_dependencies(node)
                fragment = self._extract_node(node, file_path, source, import_block, deps)
                file_fragments.append(fragment)
        
        return file_fragments

    def _extract_dependencies(self, node):
        dependencies = set()
        for child in ast.walk(node):
            if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
                dependencies.add(child.id)
            elif isinstance(child, ast.Attribute):
                if isinstance(child.value, ast.Name):
                    dependencies.add(child.attr)
        return list(dependencies)

    def _is_inside_class(self, node, tree):
        for parent in ast.walk(tree):
            if isinstance(parent, ast.ClassDef):
                if node in parent.body:
                    return True
        return False

    def _extract_node(self, node, original_path, source, import_block, dependencies=None):
        segment = ast.get_source_segment(source, node)
        symbol_name = node.name
        filename = f"{symbol_name}.py"
        save_path = self.output_dir / filename
        
        docstring = ast.get_docstring(node) or "No description provided."
        full_content = import_block + segment
        
        with open(save_path, "w", encoding="utf-8") as f:
            f.write(full_content)
            
        return {
            "name": symbol_name,
            "path": str(save_path),
            "description": docstring,
            "original_file": str(original_path),
            "code": full_content,
            "dependencies": dependencies or []
        }
