import os
import shutil
import requests
import zipfile
from pathlib import Path

class RepoCloner:
    def __init__(self, base_dir="/root/srp_app_builder/temp_repos"):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def clone(self, repo_url):
        """
        Clones a GitHub repository using the GitHub ZIP API to avoid dependency on system git binary.
        Works for public repositories.
        """
        parts = repo_url.rstrip("/").split("/")
        if "github.com" not in repo_url:
            raise ValueError("Only GitHub repositories are supported via ZIP API.")
        
        user = parts[-2]
        repo = parts[-1].replace(".git", "")
        
        target_dir = self.base_dir / repo
        
        for branch in ["main", "master"]:
            zip_url = f"https://github.com/{user}/{repo}/archive/refs/heads/{branch}.zip"
            try:
                print(f"[*] Attempting to download {repo} from branch {branch}...")
                response = requests.get(zip_url, stream=True, timeout=30, verify=False)
                if response.status_code == 200:
                    self._extract_zip(response, target_dir)
                    print(f"✅ Successfully cloned {repo} via ZIP API.")
                    return target_dir
            except Exception as e:
                print(f"⚠️ Failed to download branch {branch}: {e}")
        
        raise RuntimeError(f"Could not find a valid archive for {repo_url} (tried main/master).")

    def _extract_zip(self, response, target_dir):
        zip_path = self.base_dir / "temp_download.zip"
        with open(zip_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            temp_extract_dir = self.base_dir / "temp_extract"
            if temp_extract_dir.exists():
                shutil.rmtree(temp_extract_dir)
            
            zip_ref.extractall(temp_extract_dir)
            inner_folder = next(temp_extract_dir.iterdir())
            
            if target_dir.exists():
                shutil.rmtree(target_dir)
            
            shutil.move(str(inner_folder), str(target_dir))
            shutil.rmtree(temp_extract_dir)
        
        if zip_path.exists():
            os.remove(zip_path)

    def cleanup(self, repo_name):
        target_dir = self.base_dir / repo_name
        if target_dir.exists():
            shutil.rmtree(target_dir)
