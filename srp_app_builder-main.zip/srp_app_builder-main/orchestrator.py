import os
from srp_app_builder.core.cloner import RepoCloner
from srp_app_builder.core.splitter import ASTSplitter
from srp_app_builder.store.index import IndexedStore
from srp_app_builder.generator.assembler import AIAppGenerator
from srp_app_builder.generator.compiler import APKCompiler

class SRPAppBuilder:
    def __init__(self):
        self.cloner = RepoCloner()
        self.splitter = ASTSplitter()
        self.store = IndexedStore()
        self.generator = AIAppGenerator(self.store)

    def ingest_repository(self, repo_url):
        print(f"[*] Ingesting {repo_url}...")
        repo_path = self.cloner.clone(repo_url)
        fragments = self.splitter.analyze_and_split(repo_path)
        
        count = 0
        for frag in fragments:
            self.store.add_fragment(
                symbol_name=frag['name'],
                description=frag['description'],
                code=open(frag['path'], 'r').read(),
                dependencies=[],
                original_repo=repo_url,
                file_path=frag['path']
            )
            count += 1
        print(f"[+] Successfully indexed {count} SRP fragments.")

    def build_app_from_idea(self, user_idea):
        print(f"[*] Analyzing idea: {user_idea}")
        keywords = user_idea.split()
        selected_ids = []
        for kw in keywords:
            results = self.store.search(kw)
            for res in results:
                selected_ids.append(res[0])
        
        selected_ids = list(set(selected_ids))
        if not selected_ids:
            print("[-] No relevant fragments found in store.")
            return None

        print(f"[*] Found {len(selected_ids)} relevant fragments. Assembling...")
        app_path = self.generator.create_app_package(selected_ids, user_idea)
        print(f"[+] App assembled at: {app_path}")
        
        print("[*] Attempting to compile APK...")
        compiler = APKCompiler(app_path)
        build_log = compiler.compile()
        print(build_log)
        
        return app_path

if __name__ == "__main__":
    builder = SRPAppBuilder()
    print("SRP App Builder initialized. Use the class in your main script.")
