import os
from core.cloner import RepoCloner
from core.splitter import ASTSplitter
from store.index import IndexedStore

class SRPOrchestrator:
    def __init__(self):
        self.cloner = RepoCloner()
        self.splitter = ASTSplitter()
        self.store = IndexedStore()

    def process_repo(self, repo_url):
        print(f"Cloning {repo_url}...")
        repo_path = self.cloner.clone(repo_url)
        
        print("Splitting code into SRP fragments...")
        fragments = self.splitter.split_repo(repo_path)
        
        print("Indexing fragments...")
        for frag in fragments:
            self.store.add_fragment(
                symbol_name=frag['name'],
                description=frag['description'],
                code=frag['code'],
                dependencies=frag['dependencies'],
                original_repo=repo_url,
                file_path=frag['path']
            )
        print("Done.")

    def assemble_app(self, user_description):
        pass
