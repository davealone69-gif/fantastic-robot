import os
import shutil
from pathlib import Path

class AIAppGenerator:
    def __init__(self, store):
        self.store = store

    def create_app_package(self, selected_ids, description, output_path):
        print(f"[*] Assembling app: {description}")
        out_dir = Path(output_path)
        out_dir.mkdir(parents=True, exist_ok=True)
        
        modules_dir = out_dir / "modules"
        modules_dir.mkdir(exist_ok=True)
        
        final_ids = set(selected_ids)
        to_process = list(selected_ids)
        
        print("[*] Resolving dependency graph...")
        while to_process:
            fid = to_process.pop()
            deps = self.store.get_dependencies(fid)
            for dep_id in deps:
                if dep_id not in final_ids:
                    final_ids.add(dep_id)
                    to_process.append(dep_id)
        
        print(f"[*] Total fragments to include: {len(final_ids)} (Initial: {len(selected_ids)})")

        for fid in final_ids:
            frag = self.store.get_fragment(fid)
            if frag:
                safe_name = "".join([c if c.isalnum() else "_" for c in frag['name']])
                with open(modules_dir / f"{safe_name}.py", "w") as f:
                    f.write(frag['code'])
        
        main_py_content = f"""
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button

class SRPApp(App):
    def build(self):
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        layout.add_widget(Label(text="SRP Assembled App", font_size='24sp'))
        layout.add_widget(Label(text="{description}", halign='center'))
        
        btn = Button(text="Check Modules", size_hint=(1, 0.2))
        btn.bind(on_press=self.on_click)
        layout.add_widget(btn)
        
        return layout

    def on_click(self, instance):
        print("Modules loaded successfully from /modules directory")

if __name__ == '__main__':
    SRPApp().run()
"""
        with open(out_dir / "main.py", "w") as f:
            f.write(main_py_content)
            
        print(f"✅ App package created at {output_path}")
        return str(out_dir)
