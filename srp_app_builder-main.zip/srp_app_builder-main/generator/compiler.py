import os
import subprocess

class APKCompiler:
    def __init__(self, app_path):
        self.app_path = app_path

    def generate_spec(self):
        spec_content = f'''
[app]
title = SRP Generated App
package.name = srpapp
package.domain = org.novaclaw
source.dir = {self.app_path}
source.include_exts = py,png,jpg,kv,atlas
version = 0.1
requirements = python3,kivy
orientation = portrait
fullscreen = 0
'''
        with open(f"{self.app_path}/buildozer.spec", "w") as f:
            f.write(spec_content)

    def compile(self):
        self.generate_spec()
        try:
            result = subprocess.run(["buildozer", "android", "debug"], cwd=self.app_path, capture_output=True, text=True)
            return result.stdout
        except FileNotFoundError:
            return "Buildozer not installed. Please install buildozer to compile APK."
