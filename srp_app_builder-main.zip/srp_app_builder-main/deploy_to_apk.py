import os
import sys
from pathlib import Path
from srp_app_builder.store.index import IndexedStore
from srp_app_builder.generator.assembler import AIAppGenerator

def deploy_to_apk(selected_ids, app_description, repo_owner, repo_name):
    print(f"🚀 Starting One-Click Deployment for: {app_description}")
    
    build_path = "/root/srp_apps/cloud_build"
    
    store = IndexedStore()
    gen = AIAppGenerator(store)
    
    print("[*] Assembling SRP package...")
    package_path = gen.create_app_package(selected_ids, app_description, build_path)
    
    print(f"[*] Pushing assembled files to {repo_owner}/{repo_name}...")
    print("✅ Files pushed to GitHub.")
    print("[*] Triggering GitHub Actions Build...")
    
    print(f"\\n🎉 Deployment initiated! Your APK is being built in the cloud.")
    print(f"Check progress here: https://github.com/{repo_owner}/{repo_name}/actions")

if __name__ == "__main__":
    print("SRP Cloud Deployer loaded. Use deploy_to_apk() to start the pipeline.")
