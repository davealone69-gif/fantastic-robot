# SRP App Builder
An IDE for assembling Android apps from GitHub fragments using AST and SRP.
