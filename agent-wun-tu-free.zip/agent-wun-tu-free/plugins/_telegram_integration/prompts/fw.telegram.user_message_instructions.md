# Telegram custom rules
{{instructions}}