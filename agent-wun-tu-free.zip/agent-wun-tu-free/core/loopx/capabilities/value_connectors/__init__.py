"""Value connector planning capability."""
