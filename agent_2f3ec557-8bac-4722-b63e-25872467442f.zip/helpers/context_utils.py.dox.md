# context_utils.py DOX

## Purpose

- Own the `context_utils.py` helper module.
- This module provides context managers/utilities for current context binding.
- Keep this file-level DOX profile synchronized with `context_utils.py` because this directory is intentionally flat.

## Ownership

- `context_utils.py` owns the runtime implementation.
- `context_utils.py.dox.md` owns durable notes about responsibilities, contracts, side effects, and verification for that implementation.
- Top-level functions:
- `use_context(lock: ThreadLockType, ctxid: str, create_if_not_exists: bool=...)`

## Runtime Contracts

- Helper modules own reusable framework APIs and must preserve public callers unless all callers, tests, and docs are updated together.
- Update this file whenever public functions, classes, persistence behavior, path/security assumptions, side effects, or cross-module contracts change.
- Observed side-effect areas: WebSocket state, settings/state persistence.
- Imported dependency areas include: `threading`, `typing`.

## Key Concepts

- Newly constructed contexts reconcile their active profile against Global
  availability before returning. Existing context lookups return the stored
  context unchanged; explicit profile and project transitions own any repair.
- Important called helpers/classes observed in the source: `AgentContext.use`, `AgentContext.first`, `AgentContext`, `Exception`, `initialize_agent`, `projects.get_context_project_name`, `projects.reconcile_agent_profile`.
- Keep request/response, tool, or helper semantics documented here at the same time as source changes.

## Work Guidance

- Preserve public helper APIs used by core code and plugins unless every caller is updated.
- Keep path, auth, secret, persistence, network, and subprocess behavior explicit and bounded.
- Prefer adding cohesive helper functions here only when behavior is reused across modules.

## Verification

- Run targeted tests for changed helper behavior; run security regressions for auth, filesystem, WebSocket, tunnel, upload, or secret-handling helpers.
- `tests/test_projects.py` verifies that lookup is read-only while context
  creation reconciles once.

## Child DOX Index

No child DOX files.
