import { QM } from './l.js';
export declare class QMFile extends QM {
    private path;
    constructor(path: string);
    put(k: string, v: any, tags?: string[], et?: number): void;
    del(k: string): boolean;
    clr(): void;
    persist(): void;
}
