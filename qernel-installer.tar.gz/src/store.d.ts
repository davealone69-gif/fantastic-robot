import type { QM } from './l.js';
export interface Store {
    get(key: string): Promise<[any, boolean]>;
    put(key: string, value: any, tags?: string[], ttl?: number): Promise<void>;
    del(key: string): Promise<boolean>;
    byTag(tag: string): Promise<[string, any][]>;
    clear(): Promise<void>;
    stats(): Promise<{
        size: number;
        max?: number;
    }>;
}
export declare class QMStore implements Store {
    private mem;
    constructor(mem: QM);
    get(k: string): Promise<[any, boolean]>;
    put(k: string, v: any, tags?: string[], ttl?: number): Promise<void>;
    del(k: string): Promise<boolean>;
    byTag(t: string): Promise<[string, any][]>;
    clear(): Promise<void>;
    stats(): Promise<{
        size: number;
        mx: number;
        idx: number;
    }>;
}
