export class HS {
    constructor(_bus) {
        this._bus = _bus;
        this.drain = 0;
    }
    set(bk) { this.cur = bk; }
    add(bk) { this.cur = bk; }
    current() { return this.cur; }
    async swap(oldBk, newBk) {
        while (this.drain > 0)
            await new Promise(r => setTimeout(r, 50));
        this.cur = newBk;
        this._bus.emit('backend:swap', { from: oldBk, to: newBk });
    }
    begin() { this.drain++; }
    end() { this.drain = Math.max(0, this.drain - 1); }
}
