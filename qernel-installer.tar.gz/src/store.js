export class QMStore {
    constructor(mem) {
        this.mem = mem;
    }
    async get(k) { return this.mem.get(k); }
    async put(k, v, tags, ttl) { this.mem.put(k, v, tags, ttl); }
    async del(k) { return this.mem.del(k); }
    async byTag(t) { return this.mem.byTag(t); }
    async clear() { this.mem.clr(); }
    async stats() { return this.mem.stats(); }
}
