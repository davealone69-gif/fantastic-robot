import type { DP, Hooks } from './d.js';
import type { Cfg } from './c.js';
export interface PatchResult {
    applied: boolean;
    reason?: string;
}
export declare class PG {
    static patchDp(dp: DP, patch: Partial<Cfg>): PatchResult;
    static patchTools(h: Hooks, patch: {
        active?: number;
        active_plus?: number;
        active_samplers?: number;
    }): {
        applied: boolean;
    };
}
