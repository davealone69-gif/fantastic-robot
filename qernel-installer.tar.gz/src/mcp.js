import { TR } from './tr.js';
import { spawn } from 'child_process';
export class MCPTransport {
    constructor(opt = { command: 'npx', args: ['-y', '@modelcontextprotocol/server-example'] }) {
        this.opt = opt;
        this.tr = new TR();
    }
    async connect() {
        try {
            spawn(this.opt.command, this.opt.args ?? [], { stdio: ['pipe', 'pipe', 'pipe'] });
            const tools = [{ name: 'mcp_tool', fn: async (_name, args) => JSON.stringify(args), desc: 'MCP tool proxy' }];
            for (const t of tools)
                this.tr.reg(t);
        }
        catch { }
    }
    registry() { return this.tr; }
    static toBk(tr) {
        return {
            async *stream(_u, _h, _i, _t, _m, _sig) {
                yield { type: 'tool.call', data: { tools: tr.list() } };
            },
        };
    }
}
