import readline from 'readline';
import { init, TR, SN, UC, TDr, IC } from './q.js';
export async function repl(cfg) {
    const rt = init(cfg);
    const tr = new TR();
    const td = new TDr(tr);
    const uc = new UC();
    const ic = new IC(rt);
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, prompt: 'q> ' });
    rl.prompt();
    rl.on('line', async (line) => {
        const t = line.trim();
        if (!t) {
            rl.prompt();
            return;
        }
        if (t === ':exit') {
            rl.close();
            process.exit(0);
        }
        if (t === ':tools') {
            console.log(tr.list());
            rl.prompt();
            return;
        }
        if (t === ':usage') {
            console.log(uc.get());
            rl.prompt();
            return;
        }
        if (t === ':snap') {
            console.log(JSON.stringify(SN.from(rt), null, 2));
            rl.prompt();
            return;
        }
        if (t.startsWith(':') && t.includes(' ')) {
            console.log(ic.inspect(t));
            rl.prompt();
            return;
        }
        try {
            const base = (_d, _sig) => rt.session.run(t, '');
            const src = td.wrap(base);
            const res = await rt.dave.ge(src, { data: { prompt: t } });
            process.stdout.write(res.msg);
        }
        catch (e) {
            console.error(e);
        }
        rl.prompt();
    });
}
