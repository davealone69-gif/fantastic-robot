export type Flg = 0 | 1;
export type Tier = 0 | 1 | 2 | 3 | 4 | 5;
export type Cb = (...a: any[]) => void;
export interface GD {
    temperature?: number;
    top_k?: number;
    top_p?: number;
    rep_pen?: number;
    banned_strings?: string[];
    prompt?: string;
    [k: string]: unknown;
}
export interface SC {
    text: string;
    raw?: unknown;
}
export interface Src {
    (d: GD, s: AbortSignal): AsyncGenerator<SC>;
}
export interface Res {
    msg: string;
    con: string;
    chk: string;
}
export interface Cfg {
    gib_on: Flg;
    sample_size: number;
    gib_words: number;
    gib_min: number;
    gib_words_repeat_lrg: number;
    gib_words_repeat_sml: number;
    gib_words_max_size: number;
    gib_words_max_size_dash: number;
    gib_sent_min: number;
    gib_sent_min_size: number;
    gib_sent_min_required: number;
    gib_sent_repeat: number;
    gib_para_min: number;
    gib_para_min_size: number;
    gib_para_min_required: number;
    gib_regex: Flg;
    gib_error_scramble: Tier;
    paragraph_signal_on: Flg;
    sentence_signal_on: Flg;
    reconsider_scramble: Tier;
    dice_max_on: Flg;
    signal_on: Flg;
    dice_temp_topk_on: Flg;
    dice_temp_topk_chance: number;
    dice_temp_range: number;
    dice_topk_range: number;
    dice_XTC_on: Flg;
    dice_XTC_chance: number;
    dice_XTC_prob: number;
    dice_XTC_thre: number;
}
export interface Tog {
    active: Flg;
    active_plus: Flg;
    active_samplers: Flg;
}
export interface CL {
    loc: 0 | 1 | 2 | 3;
}
export interface MW {
    v: 0 | 1 | 2;
}
export interface NM {
    id: string;
    load: number;
    lat: number;
    err: number;
    thr: number;
    ent: number;
    lu: number;
}
export interface GS {
    nodes: number;
    avg_ent: number;
    avg_load: number;
    avg_lat: number;
    tot_thr: number;
    ts: number;
}
export interface SE {
    type: 'text.delta' | 'tool.call' | 'done' | 'error' | 'backend.status';
    data: Record<string, unknown>;
}
export interface BK {
    stream(a: string, b: any[], c: string, d: any[], e?: number, f?: AbortSignal): AsyncGenerator<SE>;
}
export interface AD {
    name: string;
    backend: BK;
}
export interface CFG {
    nodeId: string;
    interval: number;
    tiers: Record<string, Partial<Cfg>>;
    rules: Array<{
        if: Record<string, any>;
        then: {
            tier: string;
            reason: string;
        };
    }>;
}
