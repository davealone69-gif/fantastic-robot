import { EventEmitter } from 'events';
import { createRequire } from 'module';
const req = createRequire(import.meta.url);
export const TD = 'text.delta';
export const TC = 'tool.call';
export const DN = 'done';
export const ER = 'error';
export const BS = 'backend.status';
export class OB extends EventEmitter {
    constructor(base, model, key) {
        super();
        this.base = base;
        this.model = model;
        this.key = key;
    }
    async *stream(u, h, i, t, m, _sig) {
        const msgs = [{ role: 'system', content: i }, ...h, { role: 'user', content: u }];
        const body = { model: this.model, messages: msgs, stream: true, options: { num_ctx: m ?? 2048 } };
        if (t?.length)
            body.tools = t;
        const r = await fetch(`${this.base}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
        if (!r.ok) {
            yield { type: ER, data: { message: `Ollama ${r.status}` } };
            return;
        }
        const rd = r.body?.getReader();
        const dc = new TextDecoder();
        let buf = '';
        while (true) {
            const { value, done } = await rd.read();
            if (done)
                break;
            buf += dc.decode(value, { stream: true });
            const lines = buf.split('\n');
            buf = lines.pop() ?? '';
            for (const ln of lines) {
                const s = ln.trim();
                if (!s.startsWith('data: '))
                    continue;
                const raw = s.slice(6);
                if (raw === '[DONE]')
                    continue;
                try {
                    const j = JSON.parse(raw);
                    const txt = j.message?.content ?? '';
                    if (txt)
                        yield { type: TD, data: { delta: txt } };
                    if (j.done)
                        yield { type: DN, data: { cognitive_state: null, stats: { prompt_eval_count: j.prompt_eval_count, eval_count: j.eval_count } } };
                }
                catch { }
            }
        }
    }
}
export class KB extends EventEmitter {
    constructor(base, key, to = 60000) {
        super();
        this.base = base;
        this.key = key;
        this.to = to;
    }
    async *stream(u, _h, i, _t, m, _sig) {
        const msgs = [{ role: 'system', content: i }, { role: 'user', content: u }];
        const r = await fetch(`${this.base}/chat/completions`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${this.key}`, Accept: 'text/event-stream' }, body: JSON.stringify({ model: 'kimi-k2-0711-preview', messages: msgs, stream: true, max_tokens: m }) });
        if (!r.ok) {
            yield { type: ER, data: { message: `Kimi ${r.status}` } };
            return;
        }
        const rd = r.body?.getReader();
        const dc = new TextDecoder();
        let buf = '';
        while (true) {
            const { value, done } = await rd.read();
            if (done)
                break;
            buf += dc.decode(value, { stream: true });
            const lines = buf.split('\n');
            buf = lines.pop() ?? '';
            for (const ln of lines) {
                const s = ln.trim();
                if (!s.startsWith('data:'))
                    continue;
                const raw = s.slice(5).trim();
                if (!raw || raw === '[DONE]')
                    continue;
                try {
                    const j = JSON.parse(raw);
                    const txt = j.choices?.[0]?.delta?.content ?? '';
                    if (txt)
                        yield { type: TD, data: { delta: txt } };
                }
                catch { }
            }
        }
        yield { type: DN, data: { cognitive_state: null, stats: {} } };
    }
}
export class CB {
    constructor(cmd = 'codex', args = ['-q', '--quiet']) {
        this.cmd = cmd;
        this.args = args;
    }
    async *stream(u, _h, i, _t, _m, _sig) {
        const cp = req('child_process');
        const p = cp.spawn(this.cmd, [...this.args, '-p', i, u], { stdio: ['pipe', 'pipe', 'pipe'] });
        for await (const d of p.stdout) {
            const s = d.toString();
            yield { type: TD, data: { delta: s } };
        }
        yield { type: DN, data: { cognitive_state: null, stats: {} } };
    }
}
export function mkB(cfg) {
    switch (cfg.type) {
        case 'ollama': return new OB(cfg.base ?? 'http://127.0.0.1:11434', cfg.model ?? 'llama3', cfg.key ?? '');
        case 'kimi': return new KB(cfg.base ?? 'https://api.moonshot.cn', cfg.key ?? '');
        case 'codex': return new CB();
        default: throw new Error(`unknown backend ${cfg.type}`);
    }
}
