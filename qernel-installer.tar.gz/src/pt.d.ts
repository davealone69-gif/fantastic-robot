export interface PT {
    render(ctx: Record<string, any>): string;
    vars(): string[];
}
export declare class SimplePT implements PT {
    private tpl;
    private vars2;
    constructor(tpl: string);
    render(ctx: Record<string, any>): string;
    vars(): string[];
}
export declare class ChatPT implements PT {
    render(ctx: Record<string, any>): string;
    vars(): string[];
}
