export class AG {
    constructor(init, fn) {
        this.init = init;
        this.fn = fn;
    }
    async run(chunks) { let a = this.init; for (let i = 0; i < chunks.length; i++)
        a = await this.fn(a, chunks[i], i); return a; }
    async *runGen(input) {
        let a = this.init;
        let idx = 0;
        for await (const c of input) {
            a = await this.fn(a, c, idx++);
            yield a;
        }
    }
}
export const textJoin = (a, c) => a + (c.text ?? '');
export const tokenCount = (a, c) => a + (c.text?.length ?? 0);
export const latSampler = (arr, _c, _idx) => { arr.push(Date.now()); return arr; };
