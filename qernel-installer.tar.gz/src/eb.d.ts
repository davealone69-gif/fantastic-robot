type Handler = (...a: any[]) => void | Promise<void>;
export type OnFn = (name: string, fn: Handler) => () => void;
export type JoinFn = (name2: string) => (name: string) => string;
export declare class EB {
    private m;
    on(name: string, fn: Handler): () => void;
    off(name: string, fn: Handler): void;
    emit(name: string, ...a: any[]): void;
    join(name2: string): (name: string) => string;
    private match;
}
export {};
