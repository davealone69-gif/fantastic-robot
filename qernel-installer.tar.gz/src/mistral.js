export class MistralBk {
    constructor(key, model = 'mistral-small-latest', base = 'https://api.mistral.ai') {
        this.key = key;
        this.model = model;
        this.base = base;
    }
    async *stream(u, _h, i, _t, _m, _sig) {
        const r = await fetch(`${this.base}/v1/chat/completions`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${this.key}` }, body: JSON.stringify({ model: this.model, messages: [{ role: 'system', content: i }, { role: 'user', content: u }], stream: true }) });
        if (!r.ok) {
            yield { type: 'error', data: { message: `Mistral ${r.status}` } };
            return;
        }
        const rd = r.body?.getReader();
        const dc = new TextDecoder();
        let buf = '';
        while (true) {
            const { value, done } = await rd.read();
            if (done)
                break;
            buf += dc.decode(value, { stream: true });
            const lines = buf.split('\n');
            buf = lines.pop() ?? '';
            for (const ln of lines) {
                const s = ln.trim();
                if (!s.startsWith('data:'))
                    continue;
                try {
                    const j = JSON.parse(s.slice(5));
                    const d = j.choices?.[0]?.delta?.content ?? '';
                    if (d)
                        yield { type: 'text.delta', data: { delta: d } };
                }
                catch { }
            }
        }
        yield { type: 'done', data: { cognitive_state: null, stats: {} } };
    }
}
