export class TR {
    constructor() {
        this.m = new Map();
        this.d = new Map();
    }
    reg(t) { this.m.set(t.name, t.fn); if (t.desc)
        this.d.set(t.name, t.desc); }
    unreg(n) { this.m.delete(n); this.d.delete(n); }
    has(n) { return this.m.has(n); }
    list() { return [...this.m.keys()].map(n => ({ name: n, desc: this.d.get(n) })); }
    async run(name, args, ctx = {}) {
        const fn = this.m.get(name);
        if (!fn)
            throw new Error(`tool missing: ${name}`);
        return await fn(name, args, ctx);
    }
    toBk() {
        const self = this;
        return {
            async *stream(_u, _h, _i, _t, _m, _sig) {
                yield { type: 'tool.call', data: { tools: self.list() } };
            },
        };
    }
}
