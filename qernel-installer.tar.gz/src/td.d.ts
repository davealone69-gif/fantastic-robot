import type { Src, SC, SE } from './t.js';
import { TR } from './tr.js';
export declare class TDr {
    private tr;
    constructor(tr: TR);
    wrap(src: Src): Src;
    dispatch(gen: AsyncGenerator<SC>, sig: AbortSignal): AsyncGenerator<SC>;
}
export declare function normalizeSE(ev: SE): SC;
