import type { SC } from './t.js';
export type PPFn = (c: SC, idx: number) => SC | null | Promise<SC | null>;
export declare class PP {
    private fns;
    use(fn: PPFn): this;
    run(chunks: SC[]): Promise<SC[]>;
    runGen(input: AsyncGenerator<SC>): AsyncGenerator<SC>;
}
