export class LC {
    constructor(rt, opt = {}) {
        this.rt = rt;
        this.opt = opt;
        this.phase = 'init';
    }
    async start() { this.phase = 'running'; }
    async stop() {
        this.phase = 'draining';
        try {
            this.rt.dave.e?.m?.reset?.();
        }
        catch { }
        try {
            this.rt.tele?.stop?.(this.opt.drainMs ?? 2000);
        }
        catch { }
        this.phase = 'stopped';
    }
    status() { return this.phase; }
}
