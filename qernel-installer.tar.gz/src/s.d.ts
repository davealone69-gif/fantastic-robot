export declare const TD = "text.delta";
export declare const TC = "tool.call";
export declare const DN = "done";
export declare const ER = "error";
export declare const BS = "backend.status";
export interface EV {
    type: string;
    data: Record<string, any>;
}
export declare class SS {
    backend: any;
    tools: any[];
    maxTokens: number;
    cancel: AbortController;
    history: any[];
    constructor(bk: any, tools?: any[]);
    run(msg: string, sys: string): AsyncGenerator<import("./t.js").SC, void, unknown>;
    cancel_(): void;
}
