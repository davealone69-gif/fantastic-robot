export class TC {
    constructor(strategy = 'chars') { this.s = strategy; }
    estimate(chunks) { if (this.s === 'off')
        return 0; const text = chunks.map(c => c.text ?? '').join(''); if (this.s === 'tokens')
        return Math.ceil(text.length / 4); return text.length; }
    reserve(sys, tools, hist, budget, reserved = 0.3) {
        if (this.s === 'off')
            return budget;
        const used = this.estimate([{ text: sys }, ...hist]) + this.estimateTools(tools);
        return Math.max(0, budget - used - Math.floor(budget * reserved));
    }
    estimateTools(tools) { return this.s === 'tokens' ? Math.ceil(JSON.stringify(tools).length / 4) : JSON.stringify(tools).length; }
    fit(chunks, budget) {
        if (this.s === 'off')
            return chunks;
        const out = [];
        let used = 0;
        for (let i = chunks.length - 1; i >= 0; i--) {
            const t = this.estimate([chunks[i]]);
            if (used + t > budget && out.length)
                break;
            out.unshift(chunks[i]);
            used += t;
        }
        return out;
    }
}
export function toGD(msg, budget, tc) { const est = tc.estimate([{ text: msg }]); return { prompt: msg, budget_tokens: budget, estimated_tokens: est }; }
