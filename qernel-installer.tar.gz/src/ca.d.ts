import type { GD, SE } from './t.js';
export interface CacheOpt {
    ttlMs?: number;
    maxEntries?: number;
    maxPromptBytes?: number;
}
export declare class Cache {
    private opts;
    private m;
    constructor(opts?: CacheOpt);
    key(g: GD): string;
    get(g: GD): SE[] | null;
    set(g: GD, v: SE[]): boolean;
    clear(): void;
}
export declare function cachedStream(bk: any, g: GD, sig: AbortSignal, cache: Cache): AsyncGenerator<SE>;
