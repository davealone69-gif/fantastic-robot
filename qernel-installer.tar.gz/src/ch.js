export class Ch {
    constructor() {
        this.steps = [];
        this.agents = new Map();
    }
    add(fn) { this.steps.push(fn); return this; }
    register(a) { this.agents.set(a.name, a); return this; }
    handoff(fn) {
        return (d, dp) => (async function* () {
            const h = fn(d, dp);
            const agent = h.agent;
            const reason = h.reason;
            yield { text: `[handoff:${agent} reason=${reason}]` };
        })();
    }
    parallel(fns) {
        return (d, dp) => (async function* () {
            const results = await Promise.all(fns.map(fn => (async () => { let acc = ''; for await (const c of fn(d, dp))
                acc += c.text; return acc; })()));
            for (const acc of results)
                yield { text: acc };
        })();
    }
    swarm(order) {
        const self = this;
        return (d, dp) => (async function* () {
            for (const name of order) {
                const a = self.agents.get(name);
                if (!a)
                    continue;
                let acc = '';
                for await (const c of a.fn(d, dp))
                    acc += c.text;
                yield { text: acc };
            }
        })();
    }
    async run(start, dp) {
        let cur = start;
        for (const fn of this.steps) {
            const gen = fn(cur, dp);
            let acc = '';
            for await (const c of gen)
                acc += c.text;
            cur = { ...cur, prompt: acc };
        }
        const msg = cur.prompt ?? '';
        return dp.ge({ text: msg }, {});
    }
}
