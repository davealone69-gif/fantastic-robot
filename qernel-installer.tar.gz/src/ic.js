import { SN } from './sn.js';
export class IC {
    constructor(rt) {
        this.rt = rt;
    }
    inspect(cmd) {
        const parts = cmd.trim().split(/\s+/);
        const c = parts[0];
        if (c === ':tools')
            return JSON.stringify(this.rt.dave?.e?.c ?? {}, null, 2);
        if (c === ':snap')
            return JSON.stringify(SN.from(this.rt), null, 2);
        if (c === ':backends')
            return JSON.stringify({ current: this.rt.session.backend?.base ?? 'unknown' }, null, 2);
        if (c === ':cache')
            return JSON.stringify({ entries: 0 }, null, 2);
        if (c === ':jobs')
            return JSON.stringify({ queued: 0, running: 0, done: 0, failed: 0 }, null, 2);
        if (c === ':trace')
            return JSON.stringify({ root: '0'.repeat(12), session: 'unknown' }, null, 2);
        if (c === ':metrics')
            return JSON.stringify({ calls: 0, errs: 0, avgLatMs: 0 }, null, 2);
        return 'unknown command';
    }
}
