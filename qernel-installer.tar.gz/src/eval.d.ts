import type { BK, SE } from './t.js';
export interface EvalCase {
    name: string;
    prompt: string;
    system?: string;
    expected?: string[];
    forbidden?: string[];
    tools?: any[];
    maxTokens?: number;
}
export interface EvalResult {
    name: string;
    pass: boolean;
    turns: number;
    latencyMs: number;
    errors: string[];
    output: string;
}
export declare class EvalHarness {
    private results;
    run(cases: EvalCase[], backend: BK): Promise<EvalResult[]>;
    private check;
    summary(): {
        total: number;
        pass: number;
        fail: number;
        rate: number;
    };
}
export declare class DeterministicBackend implements BK {
    private responses;
    constructor(responses: string[]);
    stream(_u: string, _h: any[], _i: string, _t: any[], _m?: number, _sig?: AbortSignal): AsyncGenerator<SE>;
}
