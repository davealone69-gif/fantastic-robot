import type { GS } from './t.js';
export interface MetricsOpt {
    maxSamples?: number;
}
export interface MetricSample {
    ts: number;
    nodes: GS[];
    calls: number;
    errs: number;
    latMs: number;
}
export declare class MX {
    private opts;
    private samples;
    private calls;
    private errs;
    private lat;
    constructor(opts?: MetricsOpt);
    record(ns: GS[], latMs: number, err?: boolean): void;
    snapshot(): {
        calls: number;
        errs: number;
        avgLatMs: number;
        samples: MetricSample[];
    };
    prometheus(): string;
}
