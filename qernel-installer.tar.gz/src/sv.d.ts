import type { BK } from './t.js';
export interface SVOpt {
    port?: number;
    allowOrigin?: string;
}
export declare class SV {
    private bk;
    private opt;
    private srv;
    constructor(bk: BK, opt?: SVOpt);
    start(port?: number): any;
    stop(): void;
}
