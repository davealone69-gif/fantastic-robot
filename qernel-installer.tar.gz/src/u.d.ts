export declare const now: () => number;
export declare const clamp: (v: number, lo: number, hi: number) => number;
export declare const sha3: (s: string) => Promise<string>;
export declare const splitPara: (t: string) => string[];
export declare const splitSen: (t: string) => string[];
export declare const splitWor: (t: string) => string[];
export declare const esc: (s: string) => string;
export declare const sleep: (ms: number) => Promise<unknown>;
