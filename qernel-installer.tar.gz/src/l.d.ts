import type { NM } from './t.js';
export declare class QM {
    private d;
    private idx;
    private mx;
    put(k: string, v: any, tags?: string[], et?: number): void;
    get(k: string): any[];
    byTag(t: string): [string, any][];
    del(k: string): boolean;
    clr(): void;
    stats(): {
        size: number;
        mx: number;
        idx: number;
    };
}
export declare class QO {
    nodes: Map<string, NM>;
    private hist;
    private er;
    rn(id: string): void;
    um(id: string, p?: {
        load?: number;
        lat?: number;
        err?: number;
        thr?: number;
    }): void;
    ce(nd: NM): number;
    so(ex?: string[]): string;
    rl(il: number, cur: Record<string, number>): Record<string, number>;
    gs(): {
        nodes: number;
        avg_ent: number;
        avg_load: number;
        avg_lat: number;
        tot_thr: number;
        ts: number;
    };
}
export declare class QN {
    id: string;
    h: string;
    ent: number;
    st: string;
    constructor(id: string);
    transition(to: 'init' | 'ready' | 'running' | 'done' | 'error'): boolean;
}
