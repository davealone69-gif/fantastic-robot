import type { QRuntime } from './q.js';
export declare class IC {
    private rt;
    constructor(rt: QRuntime);
    inspect(cmd: string): string;
}
