import type { SC } from './t.js';
export type ProgressFn = (p: {
    emitted: number;
    total?: number;
    pct?: number;
}) => void;
export declare class Prog {
    private onUpdate?;
    private emitted;
    private total?;
    constructor(onUpdate?: ProgressFn | undefined);
    update(c: SC, total?: number): void;
    reset(): void;
    snapshot(): {
        emitted: number;
        total: number | undefined;
        pct: number | undefined;
    };
}
export declare function withProgress(input: AsyncGenerator<SC>, progress: Prog, total?: number): AsyncGenerator<SC>;
