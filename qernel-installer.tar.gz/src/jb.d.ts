export type JobState = 'queued' | 'running' | 'done' | 'failed';
export interface Job {
    id: string;
    fn: () => Promise<void>;
    retries: number;
    maxRetries: number;
    backoffMs: number;
    state: JobState;
    err?: string;
}
export declare class JB {
    private concurrency;
    private jobs;
    private q;
    private running;
    constructor(concurrency?: number);
    schedule(fn: () => Promise<void>, opts?: {
        id?: string;
        maxRetries?: number;
        backoffMs?: number;
    }): Job;
    drain(): Promise<void>;
    all(): Job[];
    summary(): {
        total: number;
        queued: number;
        running: number;
        done: number;
        failed: number;
    };
}
