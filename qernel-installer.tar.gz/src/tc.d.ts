import type { SC, GD } from './t.js';
export type TCStrategy = 'chars' | 'tokens' | 'off';
export declare class TC {
    private s;
    constructor(strategy?: TCStrategy);
    estimate(chunks: SC[]): number;
    reserve(sys: string, tools: any[], hist: SC[], budget: number, reserved?: number): number;
    private estimateTools;
    fit(chunks: SC[], budget: number): SC[];
}
export declare function toGD(msg: string, budget: number, tc: TC): GD;
