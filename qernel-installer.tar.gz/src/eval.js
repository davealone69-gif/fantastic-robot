import { init } from './q.js';
export class EvalHarness {
    constructor() {
        this.results = [];
    }
    async run(cases, backend) {
        const out = [];
        for (const c of cases) {
            const t0 = Date.now();
            const rt = init({ nodeId: `eval-${c.name}`, interval: 30, tiers: {}, rules: [] });
            rt.session.backend = backend;
            if (c.tools?.length)
                rt.session.tools = c.tools;
            const errors = [];
            let turns = 0;
            let output = '';
            try {
                const res = await rt.dave.ge((_d, _sig) => rt.session.run(c.prompt, c.system ?? ''), { data: { prompt: c.prompt } });
                output = res.msg;
                turns = 1;
            }
            catch (e) {
                errors.push(e.message);
            }
            const pass = this.check(output, c.expected, c.forbidden);
            out.push({ name: c.name, pass, turns, latencyMs: Date.now() - t0, errors, output });
        }
        this.results = out;
        return out;
    }
    check(output, expected, forbidden) {
        if (expected?.length && !expected.some(e => output.includes(e)))
            return false;
        if (forbidden?.length && forbidden.some(f => output.includes(f)))
            return false;
        return true;
    }
    summary() { const p = this.results.filter(r => r.pass).length; return { total: this.results.length, pass: p, fail: this.results.length - p, rate: this.results.length ? p / this.results.length : 0 }; }
}
export class DeterministicBackend {
    constructor(responses) {
        this.responses = responses;
    }
    async *stream(_u, _h, _i, _t, _m, _sig) {
        for (const r of this.responses) {
            yield { type: 'text.delta', data: { delta: r } };
        }
        yield { type: 'done', data: { cognitive_state: null, stats: {} } };
    }
}
