import { now, clamp } from './u.js';
export class QM {
    constructor() {
        this.d = new Map();
        this.idx = new Map();
        this.mx = 10000;
    }
    put(k, v, tags, et) {
        if (this.d.size >= this.mx)
            this.clr();
        const e = { v, t: now(), a: 1, l: now(), tags: tags ?? [], et: et ?? null };
        this.d.set(k, e);
        for (const x of e.tags) {
            let s = this.idx.get(x);
            if (!s) {
                s = new Set();
                this.idx.set(x, s);
            }
            s.add(k);
        }
    }
    get(k) { const e = this.d.get(k); if (!e)
        return [null, false]; if (e.et && now() > e.t + e.et) {
        this.del(k);
        return [null, false];
    } e.a++; e.l = now(); return [e.v, true]; }
    byTag(t) { const s = this.idx.get(t); if (!s)
        return []; const r = []; for (const k of s) {
        const e = this.d.get(k);
        if (e && (!e.et || now() <= e.t + e.et))
            r.push([k, e.v]);
    } return r; }
    del(k) { const e = this.d.get(k); if (!e)
        return false; for (const x of e.tags) {
        const s = this.idx.get(x);
        if (s) {
            s.delete(k);
            if (s.size === 0)
                this.idx.delete(x);
        }
    } this.d.delete(k); return true; }
    clr() { this.d.clear(); this.idx.clear(); }
    stats() { return { size: this.d.size, mx: this.mx, idx: this.idx.size }; }
}
export class QO {
    constructor() {
        this.nodes = new Map();
        this.hist = [];
        this.er = 0.1;
    }
    rn(id) { this.nodes.set(id, { id, load: 0, lat: 0, err: 0, thr: 0, ent: 0, lu: now() }); }
    um(id, p) {
        let nd = this.nodes.get(id);
        if (!nd) {
            this.rn(id);
            nd = this.nodes.get(id);
        }
        if (p?.load != null)
            nd.load = clamp(p.load, 0, 1);
        if (p?.lat != null)
            nd.lat = clamp(p.lat, 0, 1e6);
        if (p?.err != null)
            nd.err = clamp(p.err, 0, 100);
        if (p?.thr != null)
            nd.thr = clamp(p.thr, 0, 1e6);
        nd.ent = this.ce(nd);
        nd.lu = now();
        this.hist.push([id, now(), nd.load]);
        if (this.hist.length > 1000)
            this.hist = this.hist.slice(-1000);
    }
    ce(nd) {
        const l = 1 - nd.load;
        const la = Math.max(0, 1 - nd.lat / 1000);
        const e = 1 - nd.err / 100;
        const th = Math.min(1, nd.thr / 1000);
        const a = Math.sqrt(l * l + la * la + e * e + th * th) / 2;
        return clamp(-a * Math.log2(a || 1e-9), 0, 1);
    }
    so(ex) {
        const av = [...this.nodes.keys()].filter(x => !ex?.includes(x));
        if (!av.length)
            throw new Error('no nodes');
        const w = av.map(id => { const n = this.nodes.get(id); let wt = n.ent; if (Math.random() < this.er)
            wt += Math.random() * 0.3; return Math.max(0.001, wt); });
        const tw = w.reduce((a, b) => a + b, 0);
        const r = Math.random() * tw;
        let sum = 0;
        for (let i = 0; i < av.length; i++) {
            sum += w[i];
            if (sum >= r)
                return av[i];
        }
        return av[av.length - 1];
    }
    rl(il, cur) {
        const ca = {};
        let tot = 0;
        for (const [id, nd] of this.nodes) {
            const av = Math.max(0, 1 - (cur[id] ?? 0) - nd.err / 100);
            ca[id] = av * nd.ent;
            tot += ca[id];
        }
        const tgt = Object.values(cur).reduce((a, b) => a + b, 0) + il;
        const out = {};
        let ds = 0;
        for (const [id] of this.nodes) {
            const r2 = (ca[id] ?? 0) / (tot || 1);
            const v = Math.min(1, (cur[id] ?? 0) + tgt * r2);
            out[id] = v;
            ds += v;
        }
        const cf = ds > 0 ? tgt / ds : 1;
        for (const id of Object.keys(out))
            out[id] = Math.min(1, out[id] * cf);
        return out;
    }
    gs() { const a = [...this.nodes.values()]; return { nodes: a.length, avg_ent: a.reduce((s, n) => s + n.ent, 0) / (a.length || 1), avg_load: a.reduce((s, n) => s + n.load, 0) / (a.length || 1), avg_lat: a.reduce((s, n) => s + n.lat, 0) / (a.length || 1), tot_thr: a.reduce((s, n) => s + n.thr, 0), ts: now() }; }
}
export class QN {
    constructor(id) {
        this.ent = 0;
        this.st = 'init';
        this.id = id;
        this.h = '0'.repeat(64);
    }
    transition(to) {
        const allowed = { init: ['ready'], ready: ['running'], running: ['done', 'error'], done: ['ready'], error: ['ready'] };
        if (allowed[this.st]?.includes(to)) {
            this.st = to;
            return true;
        }
        return false;
    }
}
