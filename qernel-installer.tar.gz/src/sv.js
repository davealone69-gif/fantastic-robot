import { createRequire } from 'module';
const req = createRequire(import.meta.url);
export class SV {
    constructor(bk, opt = {}) {
        this.bk = bk;
        this.opt = opt;
        const http = req('http');
        this.srv = http.createServer(async (req, res) => {
            const u = new URL(req.url, `http://${req.headers.host}`).pathname;
            const corsHeaders = { 'Access-Control-Allow-Origin': this.opt.allowOrigin ?? '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS, GET' };
            if (req.method === 'OPTIONS') {
                res.writeHead(204, corsHeaders);
                res.end();
                return;
            }
            if (u === '/v1/models' && req.method === 'GET') {
                res.writeHead(200, { 'Content-Type': 'application/json', ...corsHeaders });
                res.end(JSON.stringify({ object: 'list', data: [{ id: 'qernel', object: 'model', created: Date.now() }] }));
                return;
            }
            if (u === '/v1/chat' && req.method === 'POST') {
                let body = '';
                req.on('data', (d) => body += d.toString());
                req.on('end', async () => {
                    try {
                        const j = JSON.parse(body);
                        const msgs = j.messages ?? [];
                        const sys = msgs.find((m) => m.role === 'system')?.content ?? '';
                        const hist = msgs.filter((m) => m.role !== 'system' && m.role !== 'user').slice(-10);
                        const u = msgs.filter((m) => m.role === 'user').pop()?.content ?? '';
                        const g = { temperature: j.temperature, top_k: j.top_k, prompt: u };
                        if (j.stream) {
                            res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no', ...corsHeaders });
                            for await (const ev of this.bk.stream(g.prompt ?? '', hist, sys, [], j.max_tokens))
                                res.write(`data: ${JSON.stringify(ev)}\n\n`);
                            res.write('data: [DONE]\n\n');
                            res.end();
                        }
                        else {
                            let acc = '';
                            for await (const c of this.bk.stream(g.prompt ?? '', hist, sys, [], j.max_tokens)) {
                                if (c.type === 'text.delta')
                                    acc += c.data.delta;
                            }
                            res.writeHead(200, { 'Content-Type': 'application/json', ...corsHeaders });
                            res.end(JSON.stringify({ id: 'qernel-' + Date.now(), object: 'chat.completion', created: Date.now(), model: 'qernel', choices: [{ index: 0, message: { role: 'assistant', content: acc }, finish_reason: 'stop' }] }));
                        }
                    }
                    catch (e) {
                        res.writeHead(400, corsHeaders);
                        res.end();
                    }
                });
            }
            else {
                res.writeHead(404, corsHeaders);
                res.end();
            }
        });
    }
    start(port = 3000) { this.srv.listen(port); return this.srv; }
    stop() { this.srv.close(); }
}
