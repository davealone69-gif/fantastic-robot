import { TR } from './tr.js';
export class Agent {
    constructor(dp, src, opt = {}) {
        this.dp = dp;
        this.src = src;
        this.turns = 0;
        this.src = src;
        this.dp = dp;
        this.opt = opt;
        if (!this.opt.tools)
            this.opt.tools = new TR();
    }
    async run(start) {
        let cur = start;
        while (this.turns < (this.opt.maxTurns ?? 10)) {
            this.turns++;
            const res = await this.dp.ge(this.src, { data: cur, isCon: false, conMsg: '' });
            this.opt.onTurn?.(this.turns, res);
            const last = res.msg.slice(-200);
            if (!last.includes('[tool:') && !last.includes('[tool.result')) {
                this.opt.onStop?.('done');
                return res;
            }
            const toolMatch = last.match(/\[tool:(\w+) => (.+?)\]/g);
            if (toolMatch) {
                for (const m of toolMatch) {
                    const tm = m.match(/\[tool:(\w+) => (.+)\]/);
                    if (tm) {
                        const [, name, raw] = tm;
                        let args = {};
                        try {
                            args = JSON.parse(raw);
                        }
                        catch {
                            args = { raw };
                        }
                        const result = await this.opt.tools.run(name, args);
                        this.opt.onTool?.(name, args, result);
                        cur = { ...cur, prompt: `${res.msg}\n[result:${result}]` };
                    }
                }
                continue;
            }
            this.opt.onStop?.('done');
            return res;
        }
        this.opt.onStop?.('tool_limit');
        return await this.dp.ge(this.src, { data: cur, isCon: false, conMsg: '' });
    }
}
