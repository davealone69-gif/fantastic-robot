import type { BK, SE } from './t.js';
export declare class AnthropicBk implements BK {
    private key;
    private model;
    private base;
    constructor(key: string, model?: string, base?: string);
    stream(u: string, _h: any[], i: string, _t: any[], _m?: number, _sig?: AbortSignal): AsyncGenerator<SE>;
}
