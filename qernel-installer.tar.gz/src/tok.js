let TiktokenImpl = null;
try {
    const mod = await import('@dqbd/tiktoken');
    if (mod && mod.Tiktoken)
        TiktokenImpl = mod.Tiktoken;
}
catch { }
export class BasicTokenizer {
    encode(text) { return Array.from(text).map(c => c.charCodeAt(0)); }
    decode(ids) { return ids.map(id => String.fromCharCode(id)).join(''); }
    count(text) { return this.encode(text).length; }
}
export function estimateTokens(text, tok) { return tok.count(text); }
export class TiktokenTokenizer {
    constructor(model = 'cl100k_base') { if (TiktokenImpl)
        try {
            this.enc = new TiktokenImpl(model);
        }
        catch { } }
    encode(text) { if (!this.enc)
        return new BasicTokenizer().encode(text); const r = this.enc.encode(text); this.enc.free(); return r; }
    decode(ids) { if (!this.enc)
        return new BasicTokenizer().decode(ids); const r = this.enc.decode(ids); this.enc.free(); return r; }
    count(text) { return this.encode(text).length; }
}
