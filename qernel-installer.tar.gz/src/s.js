import { normalizeSE } from './td.js';
export const TD = 'text.delta';
export const TC = 'tool.call';
export const DN = 'done';
export const ER = 'error';
export const BS = 'backend.status';
export class SS {
    constructor(bk, tools = []) {
        this.maxTokens = 2048;
        this.cancel = new AbortController();
        this.history = [];
        this.backend = bk;
        this.tools = tools;
    }
    async *run(msg, sys) {
        this.history.push({ role: 'user', content: msg });
        const out = [];
        const tc = [];
        for await (const ev of this.backend.stream(msg, this.history.slice(0, -1), sys, this.tools, this.maxTokens, this.cancel.signal)) {
            const sc = normalizeSE(ev);
            if (ev.type === TD) {
                out.push(ev.data.delta);
            }
            else if (ev.type === TC) {
                tc.push(ev.data);
            }
            yield sc;
        }
        const txt = out.join('').trim();
        if (txt)
            this.history.push({ role: 'assistant', content: txt });
        if (tc.length)
            this.history.push({ role: 'tool_call', ...tc[0] });
    }
    cancel_() { this.cancel.abort(); this.cancel = new AbortController(); }
}
