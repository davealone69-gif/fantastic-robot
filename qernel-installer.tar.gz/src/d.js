import { DSET, DT, KWD } from './c.js';
import { clamp, splitPara, splitSen, splitWor } from './u.js';
const REG = new RegExp(KWD.source, 'u');
export class HE {
    constructor() {
        this.h = {};
    }
    on(n, fn) { this.h[n] = fn; return this; }
    em(n, ...a) { this.h[n]?.(...a); }
    raw() { return this.h; }
}
export class M {
    constructor(s, st) { this.s = s; this.st = st ?? {}; }
    set(t) { this.st.hold = t; }
    poll(t) {
        const st = this.st;
        const sz = clamp(this.s.sample_size ?? 500, 10, t.length);
        const b = t.slice(-sz);
        if (b.length < (this.s.gib_min ?? 200))
            return { trig: false, flag: 0, signal: 0 };
        const w = splitWor(b).filter(x => x.length >= (this.s.gib_words_max_size ?? 24));
        if (w.length > 0 && !REG.test(w.join(' '))) {
            st.edit_phrase = w[0];
            st.flag = 90;
            st.gib_flag = 1;
            return { trig: true, flag: 90, signal: 0 };
        }
        const p = splitPara(t);
        const last = p[p.length - 1] ?? '';
        if (p.length >= (this.s.gib_para_min_required ?? 2) && last.length >= (this.s.gib_para_min_size ?? 40)) {
            if (p.length >= 2 && p[p.length - 2] === last) {
                st.edit_phrase = last.slice(0, 40);
                st.flag = 99;
                st.gib_flag = 1;
                return { trig: true, flag: 99, signal: 0 };
            }
        }
        const sen = splitSen(t);
        if (sen.length >= (this.s.gib_sent_min_required ?? 3)) {
            const counts = new Map();
            for (const x of sen)
                counts.set(x, (counts.get(x) ?? 0) + 1);
            for (const [x, c] of counts) {
                if (c >= (this.s.gib_sent_repeat ?? 2) && x.length >= (this.s.gib_sent_min_size ?? 20)) {
                    st.edit_phrase = x;
                    st.flag = 98;
                    st.gib_flag = 1;
                    return { trig: true, flag: 98, signal: 0 };
                }
            }
        }
        if (st.stop_trigger !== 0 && st.auto_continue === 1)
            return { trig: true, flag: 0, signal: st.stop_trigger };
        return { trig: false, flag: 0, signal: 0 };
    }
    reset() { this.st = {}; }
}
export function ae(res, m, _cl) {
    const f = m.flag;
    const msg = res.msg ?? '';
    if (f === 99 || f === 90) {
        const p = splitPara(msg);
        while (p.length > 1 && p[p.length - 1].length < 40)
            p.pop();
        res.msg = p.join('\n\n').trim();
    }
    else if (f === 98) {
        const s = splitSen(res.msg);
        if (s.length > 1)
            s.pop();
        res.msg = s.join('. ').trim();
    }
    else if (f >= 92 && f <= 96) {
        const rm = 101 - f;
        const w = splitWor(res.msg);
        res.msg = w.slice(0, Math.max(0, w.length - rm)).join(' ');
    }
    return res;
}
export function sm(d, c) {
    const s = c.s;
    if (c.genRestartPrimed) {
        c.genRestart++;
        return { ...d, temperature: clamp((d.temperature ?? 0.8) + (Math.random() - 0.5) * (s.dice_temp_range ?? 500) / 500, 0.1, 2), top_k: Math.max(1, Math.round((d.top_k ?? 40) + (Math.random() - 0.5) * (s.dice_topk_range ?? 150))) };
    }
    return d;
}
export function sg(st) { st.stop_trigger = 1; st.auto_continue = 1; }
export class AC {
    static correct(e, msg) {
        const st = (e?.m?.st ?? {});
        st.flag = 0;
        st.edit_phrase = '';
        const r = e?.m?.poll?.(msg) ?? { trig: false, flag: 0 };
        if (r.flag && r.flag > 0) {
            const res = ae({ msg, con: '', chk: '' }, st, 1);
            return { msg: res.msg, flag: r.flag, phrase: st.edit_phrase ?? '' };
        }
        return { msg, flag: r.flag, phrase: st.edit_phrase ?? '' };
    }
}
export class CR {
    static armed(e) { return e.toggles?.active_plus === 1; }
    static enabled(e) { return e.toggles?.active_plus === 1; }
    static prime(e) { e.samplerCtx.genRestartPrimed = true; }
}
export class QT {
    static tier(e) { return e.settings?.gib_error_scramble ?? 0; }
    static setTier(e, t) { if (e?.settings)
        e.settings.gib_error_scramble = t; }
    static err(e) { return e.monitor?.st?.error_warn ?? 0; }
}
export class DE {
    constructor(o) {
        this.s = o.s;
        this.t = o.t;
        this.m = new M(o.s, o.st);
        this.h = new HE();
        this.h.h = o.h ?? {};
        this.c = { s: o.s, st: this.m.st, active: o.t.active === 1, active_plus: o.t.active_plus === 1, active_samplers: o.t.active_samplers === 1, genRestart: 0, genRestartPrimed: false, trigger: o.trigger ?? '', triggerCount: 0 };
    }
    async ge(src, o) {
        if (this.t.active !== 1) {
            const sig = new AbortController();
            let a = '';
            for await (const c of src(o.data, sig.signal))
                a += c.text;
            this.h.em('onFinish', a);
            return { msg: a, con: o.conMsg ?? '', chk: a };
        }
        let d = { ...o.data };
        let acc = '';
        let fk = '';
        let con = o.conMsg ?? '';
        const isCon = o.isCon ?? false;
        d = sm(d, this.c);
        const pre = this.h.raw().onPreReq?.(d);
        if (pre)
            d = pre;
        this.h.em('onResume', d);
        let rg = 0;
        const MX = 200;
        while (true) {
            if (rg++ > MX) {
                this.h.raw().debug?.('DAVE STOP: rg');
                break;
            }
            const sig = new AbortController();
            let ed = false;
            for await (const c of src(d, sig.signal)) {
                const toolR = c.raw?.type === 'tool.result' ? c.raw : undefined;
                const out = this.h.raw().onChunk?.(c, acc);
                const tx = out?.text !== undefined ? out.text : c.text;
                if (toolR) {
                    acc += `\n[tool:${toolR.data?.name ?? 'unknown'} => ${JSON.stringify(toolR.data?.result ?? '')}]\n`;
                }
                else {
                    acc += tx;
                    fk = tx;
                    this.m.set(tx);
                }
                const r = this.m.poll(acc);
                if (r.trig) {
                    if (r.flag && r.flag > 0) {
                        this.h.raw().debug?.('DAVE: edit ' + r.flag);
                        this.h.em('onEdit', r.flag, this.m.st.edit_phrase);
                        sig.abort();
                        const r2 = ae({ msg: acc, con, chk: fk }, this.m.st, 1);
                        acc = r2.msg;
                        con = r2.con;
                        fk = r2.chk;
                        this.m.reset();
                        this.h.em('onStop', 'edit');
                        ed = true;
                        break;
                    }
                    else if (r.signal && r.signal !== 0) {
                        this.h.raw().debug?.('DAVE: signal');
                        this.h.em('onSignal', this.m.st);
                        sg(this.m.st);
                        sig.abort();
                        this.h.em('onStop', 'signal');
                        break;
                    }
                }
            }
            if (ed)
                break;
            if (this.m.st.stop_trigger !== 0) {
                d = sm(d, this.c);
                this.h.em('onResume', d);
                this.m.set('');
                if (!this.m.st.auto_continue) {
                    this.h.raw().debug?.('DAVE STOP: ac');
                    break;
                }
                continue;
            }
            if (!this.m.st.auto_continue && this.m.st.auto_continue === 1) {
                this.h.raw().debug?.('DAVE STOP: ac guard');
                break;
            }
            break;
        }
        if (this.t.active === 1 && this.m.st.skip_dave_edit === 0) {
            if (this.m.st.flag > 0) {
                const r2 = ae({ msg: acc, con, chk: fk }, this.m.st, 3);
                acc = r2.msg;
                con = r2.con;
                fk = r2.chk;
                this.m.reset();
            }
        }
        if (isCon && con)
            acc = con + acc;
        this.m.st.message_watch = acc;
        this.h.em('onFinish', acc);
        return { msg: acc, con, chk: fk };
    }
}
export class DP {
    constructor(o = {}) {
        const s = { ...DSET, ...(o.s ?? {}) };
        const t = { ...DT, ...(o.t ?? {}) };
        this.e = new DE({ s, t, h: o.h, trigger: o.trigger });
    }
    get ac() { return AC; }
    get cr() { return CR; }
    get qt() { return QT; }
    async ge(src, o) { return this.e.ge(src, o); }
    co(m) { return AC.correct(this.e, m); }
    ap(p) { Object.assign(this.e.s, p); }
    rs() { this.e.m.reset(); this.e.c.genRestartPrimed = false; this.e.c.genRestart = 0; }
}
