import type { GD, SC } from './t.js';
import type { DP } from './d.js';
export type ChainFn = (d: GD, dp: DP) => AsyncGenerator<SC>;
export type HandoffFn = (d: GD, dp: DP) => {
    agent: string;
    reason: string;
};
export interface AgentDef {
    name: string;
    prompt?: string;
    fn: ChainFn;
}
export declare class Ch {
    private steps;
    private agents;
    add(fn: ChainFn): this;
    register(a: AgentDef): this;
    handoff(fn: HandoffFn): (d: GD, dp: DP) => AsyncGenerator<SC, void, unknown>;
    parallel(fns: ChainFn[]): ChainFn;
    swarm(order: string[]): ChainFn;
    run(start: GD, dp: DP): Promise<{
        msg: string;
        con: string;
        chk: string;
    }>;
}
