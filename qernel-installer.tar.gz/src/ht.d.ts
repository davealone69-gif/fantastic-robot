import type { BK } from './t.js';
export declare class HT {
    private bk;
    private port;
    constructor(bk: BK, port?: number);
    start(): any;
}
