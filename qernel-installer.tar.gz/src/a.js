export async function* oai(body, key, m) {
    const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
        body: JSON.stringify({ ...body, model: m, stream: true }),
    });
    if (!r.ok)
        throw new Error(`OpenAI ${r.status}`);
    const rd = r.body?.getReader();
    if (!rd)
        return;
    const dc = new TextDecoder();
    let buf = '';
    while (true) {
        const { value, done } = await rd.read();
        if (done)
            break;
        buf += dc.decode(value, { stream: true });
        const lines = buf.split('\n');
        buf = lines.pop() ?? '';
        for (const ln of lines) {
            const s = ln.trim();
            if (!s || s === 'data: [DONE]')
                continue;
            if (!s.startsWith('data: '))
                continue;
            try {
                const j = JSON.parse(s.slice(6));
                const delta = j.choices?.[0]?.delta?.content ?? '';
                if (delta)
                    yield { text: delta };
            }
            catch { /* skip */ }
        }
    }
}
export function fromCb(fn) {
    return async function* (d, sig) {
        const gen = fn(d, () => { }, sig);
        if (gen && typeof gen[Symbol.asyncIterator] === 'function') {
            for await (const c of gen)
                yield c;
        }
    };
}
