export class DM {
    static diff(a, b, prefix = '') {
        const out = [];
        for (const k of Object.keys(b)) {
            const p = prefix ? `${prefix}.${k}` : k;
            if (a[k] === undefined || typeof a[k] !== typeof b[k])
                out.push({ path: p, from: a[k], to: b[k] });
            else if (typeof b[k] === 'object' && b[k] !== null && !Array.isArray(b[k]))
                out.push(...this.diff(a[k], b[k], p));
            else if (a[k] !== b[k])
                out.push({ path: p, from: a[k], to: b[k] });
        }
        return out;
    }
    static merge(a, b, strategy = 'last-write-wins') {
        const out = { ...a };
        for (const k of Object.keys(b)) {
            if (strategy === 'last-write-wins')
                out[k] = b[k];
            else if (k === 'history' && Array.isArray(a.history) && Array.isArray(b.history))
                out.history = [...a.history, ...b.history];
            else if (typeof b[k] === 'object' && b[k] !== null && !Array.isArray(b[k]))
                out[k] = b[k];
            else
                out[k] = b[k];
        }
        return out;
    }
}
