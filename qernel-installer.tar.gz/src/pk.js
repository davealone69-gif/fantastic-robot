import { mkB } from './b.js';
export class PK {
    constructor() {
        this.m = new Map();
    }
    register(p) { this.m.set(p.name, p); }
    unregister(name) { this.m.delete(name); }
    get(name) { return this.m.get(name); }
    all() { return [...this.m.values()]; }
    byType(t) { return this.all().filter(p => p.type === t); }
    async loadFrom(dir) {
        try {
            const fs = await import('fs/promises');
            const path = await import('path');
            const files = await fs.readdir(dir);
            for (const f of files) {
                if (!f.endsWith('.js') && !f.endsWith('.ts'))
                    continue;
                const mod = await import(path.join(dir, f));
                const manifests = mod.default ?? mod.plugins ?? [];
                for (const m of manifests) {
                    if (m.type === 'backend') {
                        const cfg = m.config ?? {};
                        this.register({ name: m.name, type: 'backend', impl: mkB({ type: m.entry, ...cfg }), meta: m });
                    }
                }
            }
        }
        catch { /* optional feature, ignore missing dir */ }
    }
}
