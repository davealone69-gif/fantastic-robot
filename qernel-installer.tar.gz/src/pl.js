import { RT } from './rt.js';
import { RL } from './rl.js';
export class PL {
    constructor() {
        this.bks = [];
        this.cur = 0;
        this.rt = new RT({ maxRetries: 2, baseMs: 200, timeoutMs: 120000 });
        this.rl = new RL({ emit: () => { } }, { tpm: 100000, refillMs: 1000 });
    }
    add(bk) { this.bks.push(bk); return this; }
    rm(bk) { const i = this.bks.indexOf(bk); if (i >= 0)
        this.bks.splice(i, 1); }
    len() { return this.bks.length; }
    next() { if (!this.bks.length)
        throw new Error('pool empty'); return this.bks[this.cur++ % this.bks.length]; }
    fail() { this.cur = Math.max(0, this.cur - 1); }
    async *stream(u, h, i, t, m, sig) {
        if (!this.rl.allow(m ?? 1000))
            return;
        try {
            for await (const c of this.rt.exec(this.bks, (bk) => bk.stream(u, h, i, t, m, sig)))
                yield c;
        }
        catch {
            if (this.bks.length > 1) {
                const gen = this.next().stream(u, h, i, t, m, sig);
                for await (const c of gen)
                    yield c;
            }
        }
    }
}
