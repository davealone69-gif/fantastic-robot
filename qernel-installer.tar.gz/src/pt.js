export class SimplePT {
    constructor(tpl) { this.tpl = tpl; this.vars2 = [...tpl.matchAll(/\{\{\s*(\w+)\s*\}\}/g)].map(m => m[1]); }
    render(ctx) { let r = this.tpl; for (const v of this.vars2)
        r = r.replace(new RegExp(`\\{\\{\\s*${v}\\s*\\}\\}`, 'g'), ctx[v] ?? ''); return r; }
    vars() { return this.vars2; }
}
export class ChatPT {
    render(ctx) {
        const sys = ctx.system ?? '';
        const hist = ctx.history ?? [];
        const u = ctx.user ?? '';
        const tools = ctx.tools ?? [];
        const parts = [];
        if (sys)
            parts.push(`SYSTEM:\n${sys}`);
        if (tools.length)
            parts.push(`TOOLS:\n${JSON.stringify(tools, null, 2)}`);
        for (const m of hist)
            parts.push(`${m.role?.toUpperCase() ?? 'USER'}:\n${m.content}`);
        parts.push(`USER:\n${u}`);
        return parts.join('\n\n');
    }
    vars() { return ['system', 'history', 'user', 'tools']; }
}
