export declare function repl(cfg: any): Promise<void>;
