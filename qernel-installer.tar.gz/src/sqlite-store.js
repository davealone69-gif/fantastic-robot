export class SQLiteStore {
    constructor(path) {
        this.path = path;
        this.db = null;
    }
    async init() {
        try {
            const sqlite = await import('sqlite');
            this.db = await sqlite.open(this.path);
            await this.db.exec('CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT, tags TEXT, ttl INTEGER, created INTEGER)');
            await this.db.exec('CREATE INDEX IF NOT EXISTS idx_tags ON kv(tags)');
        }
        catch {
            this.db = null;
        }
    }
    async get(k) { if (!this.db)
        return [null, false]; const r = await this.db.get('SELECT value, ttl FROM kv WHERE key = ?', k); if (!r)
        return [null, false]; if (r.ttl && Date.now() > r.ttl) {
        await this.del(k);
        return [null, false];
    } return [JSON.parse(r.value), true]; }
    async put(k, v, tags, ttl) { if (!this.db)
        return; await this.db.run('INSERT OR REPLACE INTO kv (key, value, tags, ttl, created) VALUES (?, ?, ?, ?, ?)', k, JSON.stringify(v), tags?.join(',') ?? '', ttl ? Date.now() + ttl : null, Date.now()); }
    async del(k) { if (!this.db)
        return false; const r = await this.db.run('DELETE FROM kv WHERE key = ?', k); return (r.changes ?? 0) > 0; }
    async byTag(tag) { if (!this.db)
        return []; const rows = await this.db.all('SELECT key, value FROM kv WHERE tags LIKE ?', `%${tag}%`); return rows.map((r) => [r.key, JSON.parse(r.value)]); }
    async clear() { if (!this.db)
        return; await this.db.exec('DELETE FROM kv'); }
    async stats() { if (!this.db)
        return { size: 0 }; const r = await this.db.get('SELECT COUNT(*) as c FROM kv'); return { size: r.c }; }
    async close() { if (this.db)
        await this.db.close(); }
}
