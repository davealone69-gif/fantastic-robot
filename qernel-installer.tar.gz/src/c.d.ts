export interface Cfg {
    nodeId: string;
    interval: number;
    tiers: Record<string, any>;
    rules: any[];
}
export type CFG = Cfg;
export declare const DSET: Record<string, number | string>;
export declare const DT: Record<string, number>;
export declare const KWD: RegExp;
export declare const DC: Record<string, Record<string, number | string>>;
export declare const LR: {
    if: Record<string, any>;
    then: {
        tier: string;
        reason: string;
    };
}[];
export type Set = typeof DSET;
export type Tog = typeof DT;
