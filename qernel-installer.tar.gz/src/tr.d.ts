import type { BK } from './t.js';
export interface ToolCtx {
    signal?: AbortSignal;
}
export type ToolFn = (name: string, args: Record<string, any>, ctx: ToolCtx) => Promise<string> | string;
export interface ToolReg {
    name: string;
    fn: ToolFn;
    desc?: string;
}
export declare class TR {
    private m;
    private d;
    reg(t: ToolReg): void;
    unreg(n: string): void;
    has(n: string): boolean;
    list(): {
        name: string;
        desc: string | undefined;
    }[];
    run(name: string, args: Record<string, any>, ctx?: ToolCtx): Promise<string>;
    toBk(): BK;
}
