import type { GD, Src, Res } from './t.js';
import type { DP } from './d.js';
import { TR } from './tr.js';
export interface AgentOpt {
    maxTurns?: number;
    tools?: TR;
    onTool?: (name: string, args: any, result: string) => void;
    onTurn?: (turn: number, res: Res) => void;
    onStop?: (reason: 'done' | 'tool_limit' | 'error') => void;
}
export declare class Agent {
    private dp;
    private src;
    private turns;
    private opt;
    constructor(dp: DP, src: Src, opt?: AgentOpt);
    run(start: GD): Promise<Res>;
}
