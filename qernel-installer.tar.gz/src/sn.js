export class SN {
    static from(rt, opt = {}) {
        const out = { v: 1, nodeId: 'qernel', ts: Date.now(), history: rt.session.history, dave: { st: rt.dave.e.m.st } };
        if (opt.includeTele)
            out.tele = rt.tele;
        return out;
    }
    static to(s) {
        return { history: s.history, dave: { e: { m: { st: s.dave.st } } } };
    }
}
