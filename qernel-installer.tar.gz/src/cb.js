export class CB {
    constructor(failAfter = 5, recovMs = 30000, onState = () => { }) {
        this.failAfter = failAfter;
        this.recovMs = recovMs;
        this.onState = onState;
        this.state = 'closed';
        this.fails = 0;
        this.openedAt = 0;
    }
    async exec(fn, fallback) {
        this.fn = fn;
        this.fb = fallback;
        if (this.state === 'open') {
            if (Date.now() - this.openedAt < this.recovMs) {
                if (this.fb)
                    return this.fb();
                throw new Error('circuit open');
            }
            this.setState('halfOpen');
        }
        try {
            const r = await this.fn();
            if (this.state === 'halfOpen')
                this.setState('closed');
            this.fails = 0;
            return r;
        }
        catch (e) {
            this.fails++;
            if (this.fails >= this.failAfter) {
                this.openedAt = Date.now();
                this.setState('open');
                if (this.fb)
                    return this.fb();
                throw e;
            }
            throw e;
        }
    }
    setState(s) { const p = this.state; this.state = s; this.onState(p, s); }
    isOpen() { return this.state === 'open'; }
    reset() { this.setState('closed'); this.fails = 0; }
}
