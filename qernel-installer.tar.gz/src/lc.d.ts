import type { QRuntime } from './q.js';
export type Phase = 'init' | 'running' | 'draining' | 'stopped';
export interface LCOpt {
    drainMs?: number;
}
export declare class LC {
    private rt;
    private opt;
    private phase;
    constructor(rt: QRuntime, opt?: LCOpt);
    start(): Promise<void>;
    stop(): Promise<void>;
    status(): Phase;
}
