export const DSET = {
    gib_on: 1, sample_size: 500, gib_words: 50, gib_min: 200,
    gib_words_repeat_lrg: 5, gib_words_repeat_sml: 15,
    gib_words_max_size: 24, gib_words_max_size_dash: 48,
    gib_sent_min: 200, gib_sent_min_size: 20, gib_sent_min_required: 3,
    gib_sent_repeat: 2, gib_para_min: 200, gib_para_min_size: 40,
    gib_para_min_required: 2, gib_regex: 1, gib_error_scramble: 2,
    paragraph_signal_on: 1, sentence_signal_on: 0, reconsider_scramble: 0,
    dice_max_on: 0, signal_on: 1, dice_temp_topk_on: 1,
    dice_temp_topk_chance: 0, dice_temp_range: 500, dice_topk_range: 150,
    dice_XTC_on: 1, dice_XTC_chance: 5, dice_XTC_prob: 100, dice_XTC_thre: 100,
};
export const DT = { active: 1, active_plus: 0, active_samplers: 0 };
export const KWD = /^[~`!@#$%^&*()_+–…©™’'\-\. \n=[\]\{}|;':",.\/<>?a-zA-Z0-9-]+$/;
export const DC = {
    "0": { label: 'off' },
    "1": { label: 'min', gib_on: 1, active: 1, gib_error_scramble: 1 },
    "2": { label: 'bal', gib_on: 1, active: 1, active_plus: 1, gib_error_scramble: 2, paragraph_signal_on: 1, reconsider_scramble: 1, signal_on: 1 },
    "3": { label: 'agg', gib_on: 1, active: 1, active_plus: 1, active_samplers: 1, gib_error_scramble: 3, paragraph_signal_on: 1, sentence_signal_on: 1, reconsider_scramble: 2, signal_on: 1, dice_temp_topk_on: 1, dice_temp_range: 350, dice_topk_range: 100 },
    "4": { label: 'hvy', gib_on: 1, active: 1, active_plus: 1, active_samplers: 1, gib_error_scramble: 4, paragraph_signal_on: 1, sentence_signal_on: 1, reconsider_scramble: 3, signal_on: 1, dice_temp_topk_on: 1, dice_temp_range: 600, dice_topk_range: 200 },
    "5": { label: 'max', gib_on: 1, active: 1, active_plus: 1, active_samplers: 1, gib_error_scramble: 5, paragraph_signal_on: 1, sentence_signal_on: 1, reconsider_scramble: 4, signal_on: 1, dice_max_on: 1, dice_temp_topk_on: 1, dice_temp_range: 800, dice_topk_range: 300 },
};
export const LR = [
    { if: { node_label_contains: 'data_processor', entropy_below: 0.2 }, then: { tier: '3', reason: 'low entropy' } },
    { if: { node_label_contains: 'api_gateway', latency_above_ms: 500 }, then: { tier: '4', reason: 'high latency' } },
    { if: { node_label_contains: 'analytics_engine', error_rate_above: 2 }, then: { tier: '5', reason: 'analytics errors' } },
    { if: { avg_ent_below: 0.15, max_load_above: 0.85 }, then: { tier: '4', reason: 'system stress' } },
    { if: { avg_ent_above: 0.7, max_load_below: 0.4 }, then: { tier: '1', reason: 'healthy system' } },
];
