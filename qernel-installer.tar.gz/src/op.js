export class OP {
    static json(txt) { const m = txt.match(/\{[\s\S]*\}/); if (!m)
        throw new Error('no json'); return JSON.parse(m[0]); }
    static regex(txt, pattern) { const m = txt.match(new RegExp(pattern)); return m ? m[1] ?? m[0] : null; }
    static field(txt, field) { const m = txt.match(new RegExp(`^${field}\\s*[:=]\\s*(.+)$`, 'm')); return m ? m[1].trim() : null; }
    static validate(txt, schema) {
        try {
            const obj = this.json(txt);
            if (schema.type !== 'object' || typeof obj !== 'object' || obj === null)
                return false;
            if (schema.required)
                for (const k of schema.required)
                    if (!(k in obj))
                        return false;
            if (schema.properties)
                for (const [k, v] of Object.entries(schema.properties))
                    if (obj[k] !== undefined && typeof obj[k] !== v.type)
                        return false;
            return true;
        }
        catch {
            return false;
        }
    }
}
