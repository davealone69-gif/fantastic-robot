export interface RLOpt {
    rpm?: number;
    tpm?: number;
    refillMs?: number;
}
export declare class RL {
    private tpm;
    private refillMs;
    private tokens;
    private last;
    constructor(_bus: {
        emit: (n: string, ...a: any[]) => void;
    }, opt?: RLOpt);
    allow(tokens?: number): boolean;
}
export declare function perBackendRL(_bks: Pick<any, 'stream'>[], opts: RLOpt): RL[];
