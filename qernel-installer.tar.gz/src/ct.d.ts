export declare class CTS {
    private aborted;
    constructor(_parent?: AbortSignal);
    abort(): void;
    signal(): AbortSignal;
    throwIf(): void;
}
export declare function link(parent: AbortSignal): CTS;
