import { rootTrace, sessionId } from './trace.js';
export class DB {
    constructor(orch, mem, nid = 'qernel') {
        this.q = [];
        this.run = false;
        this.nid = 'qernel';
        this.orch = orch;
        this.mem = mem;
        this.nid = nid;
    }
    start() { if (this.run)
        return; this.run = true; this.th = setInterval(() => this._wk(), 100); }
    stop(_t = 2000) { this.run = false; clearInterval(this.th); }
    feed(ev) { this.q.push(ev); }
    setCallbacks(onUsage, onMetric) { this.onUsage = onUsage; this.onMetric = onMetric; }
    snapshot() { return { queue: this.q.length, memEntries: this.mem?.stats?.()?.size ?? 0 }; }
    _wk() { while (this.q.length) {
        const e = this.q.shift();
        this._pr(e);
    } }
    _pr(e) {
        let ld = 0, er = 0, th = 1;
        if (e.type === 'onPreReq') {
            ld = 0.05;
            th = 0.5;
            this.mem?.put(`dave:${e.type}:${e.ts}`, e.payload, ['dave', this.nid, 'pre'], 3600);
        }
        else if (e.type === 'onChunk') {
            ld = Math.min(0.3, (e.len ?? 0) / 5000);
            this.mem?.put(`dave:${e.type}:${e.ts}`, { len: e.len }, ['dave', this.nid], 3600);
        }
        else if (e.type === 'onEdit') {
            ld = 0.6;
            er = 10;
            th = 0.2;
            this.mem?.put(`dave:${e.type}:${e.ts}`, { flag: e.flag, phrase: e.phrase }, ['dave', this.nid, 'edit'], 3600);
        }
        else if (e.type === 'onSignal') {
            ld = 0.5;
            er = 5;
            th = 0.4;
            this.mem?.put(`dave:${e.type}:${e.ts}`, e.payload, ['dave', this.nid, 'signal'], 3600);
        }
        else if (e.type === 'onStop') {
            ld = 0.7;
            er = 8;
            th = 0.1;
            this.mem?.put(`dave:${e.type}:${e.ts}`, e.payload, ['dave', this.nid, 'stop'], 3600);
        }
        else if (e.type === 'onResume') {
            ld = 0.4;
            th = 0.6;
            this.mem?.put(`dave:${e.type}:${e.ts}`, e.payload, ['dave', this.nid, 'resume'], 3600);
        }
        else if (e.type === 'onFinish') {
            ld = 0.2;
            th = 1;
            const msgLen = (e.payload?.message ?? '').length;
            this.mem?.put(`dave:${e.type}:${e.ts}`, { len: msgLen }, ['dave', this.nid, 'finish'], 3600);
            this.onUsage?.(msgLen, msgLen);
        }
        else if (e.type === 'onError') {
            ld = 0.9;
            er = 25;
            th = 0;
            this.mem?.put(`dave:${e.type}:${e.ts}`, { error: e.payload?.error ?? '' }, ['dave', this.nid, 'error'], 3600);
            this.onMetric?.([], 0, true);
        }
        this.orch?.um?.(this.nid, { load: ld, lat: 0, err: er, thr: th });
        this.onMetric?.([], 0, e.type === 'onError');
    }
}
export function mkTL(o) {
    const nid = o?.nid ?? 'qernel';
    const sink = o?.s;
    const trace = rootTrace();
    const sid = sessionId();
    return {
        onPreReq: (d) => { const e = { type: 'onPreReq', ts: Date.now(), nid, payload: d, traceId: trace, sessionId: sid }; if (sink)
            sink(e); return d; },
        onChunk: (c, a) => { const e = { type: 'onChunk', ts: Date.now(), nid, payload: c, len: a.length, traceId: trace, sessionId: sid }; if (sink)
            sink(e); return c; },
        onEdit: (f, p) => { const e = { type: 'onEdit', ts: Date.now(), nid, payload: {}, flag: f, phrase: p, traceId: trace, sessionId: sid }; if (sink)
            sink(e); },
        onSignal: (s) => { const e = { type: 'onSignal', ts: Date.now(), nid, payload: s, traceId: trace, sessionId: sid }; if (sink)
            sink(e); },
        onStop: (r) => { const e = { type: 'onStop', ts: Date.now(), nid, payload: { reason: r }, traceId: trace, sessionId: sid }; if (sink)
            sink(e); },
        onResume: (d) => { const e = { type: 'onResume', ts: Date.now(), nid, payload: d, traceId: trace, sessionId: sid }; if (sink)
            sink(e); },
        onFinish: (m) => { const e = { type: 'onFinish', ts: Date.now(), nid, payload: { message: m }, traceId: trace, sessionId: sid }; if (sink)
            sink(e); },
        onError: (e) => { const ev = { type: 'onError', ts: Date.now(), nid, payload: { error: e.message }, traceId: trace, sessionId: sid }; if (sink)
            sink(ev); },
    };
}
