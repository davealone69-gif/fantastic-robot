export class CTS {
    constructor(_parent) {
        this.aborted = false;
        if (_parent)
            _parent.addEventListener('abort', () => this.abort());
    }
    abort() { this.aborted = true; }
    signal() { const s = new AbortController(); if (this.aborted)
        s.abort(); return s.signal; }
    throwIf() { if (this.aborted)
        throw new Error('canceled'); }
}
export function link(parent) { const cts = new CTS(); parent.addEventListener('abort', () => cts.abort()); return cts; }
