import { clamp } from './u.js';
export class RT {
    constructor(opts = {}) {
        this.opts = opts;
    }
    async *exec(bks, fn, fallback) {
        const max = this.opts.maxRetries ?? 3;
        const base = this.opts.baseMs ?? 200;
        let lastError;
        for (let i = 0; i < bks.length; i++) {
            const bk = bks[i];
            let retries = 0;
            while (retries <= max) {
                try {
                    const sig = new AbortController();
                    const t = setTimeout(() => sig.abort(), this.opts.timeoutMs ?? 120000);
                    const gen = fn(bk);
                    try {
                        for await (const c of gen)
                            yield c;
                        clearTimeout(t);
                        return;
                    }
                    catch (e) {
                        clearTimeout(t);
                        throw e;
                    }
                }
                catch (e) {
                    lastError = e;
                    retries++;
                    if (retries <= max)
                        await new Promise(r => setTimeout(r, clamp(base * Math.pow(2, retries) + Math.random() * 100, 0, 30000)));
                }
            }
        }
        if (fallback)
            for await (const c of fallback())
                yield c;
        else
            throw lastError ?? new Error('retry exhausted');
    }
    static select(bks) {
        return bks.sort((a, b) => a.score - b.score);
    }
}
