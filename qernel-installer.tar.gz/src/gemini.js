export class GeminiBk {
    constructor(key, model = 'gemini-1.5-flash', base = 'https://generativelanguage.googleapis.com') {
        this.key = key;
        this.model = model;
        this.base = base;
    }
    async *stream(u, _h, i, _t, _m, _sig) {
        const url = `${this.base}/v1beta/models/${this.model}:streamGenerateContent?alt=sse&key=${this.key}`;
        const body = { contents: [{ parts: [{ text: u }] }], systemInstruction: { parts: [{ text: i }] } };
        const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
        if (!r.ok) {
            yield { type: 'error', data: { message: `Gemini ${r.status}` } };
            return;
        }
        const rd = r.body?.getReader();
        const dc = new TextDecoder();
        let buf = '';
        while (true) {
            const { value, done } = await rd.read();
            if (done)
                break;
            buf += dc.decode(value, { stream: true });
            const lines = buf.split('\n');
            buf = lines.pop() ?? '';
            for (const ln of lines) {
                try {
                    const j = JSON.parse(ln);
                    const d = j.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
                    if (d)
                        yield { type: 'text.delta', data: { delta: d } };
                }
                catch { }
            }
        }
        yield { type: 'done', data: { cognitive_state: null, stats: {} } };
    }
}
