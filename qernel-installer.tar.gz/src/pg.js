export class PG {
    static patchDp(dp, patch) {
        const e = dp.e;
        if (!e)
            return { applied: false, reason: 'no dave engine' };
        Object.assign(e.s, patch);
        return { applied: true };
    }
    static patchTools(h, patch) {
        h.onPreReq = (d) => { Object.assign(d.toggles ?? (d.toggles = {}), patch); return d; };
        return { applied: true };
    }
}
