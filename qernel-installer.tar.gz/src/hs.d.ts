import type { BK } from './t.js';
export declare class HS {
    private _bus;
    private cur?;
    private drain;
    constructor(_bus: {
        emit: (n: string, ...a: any[]) => void;
    });
    set(bk: BK): void;
    add(bk: BK): void;
    current(): BK | undefined;
    swap(oldBk: BK, newBk: BK): Promise<void>;
    begin(): void;
    end(): void;
}
