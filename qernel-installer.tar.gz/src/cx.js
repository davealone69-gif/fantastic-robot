export class CX {
    constructor(strategy = 'sliding', _maxTokens = 4096) { this.s = strategy; }
    estimate(chunks) { return chunks.reduce((a, c) => a + (c.text?.length ?? 0), 0); }
    fit(chunks, budget) {
        if (this.s === 'off')
            return chunks;
        const out = [];
        let used = 0;
        for (let i = chunks.length - 1; i >= 0; i--) {
            const t = (chunks[i].text?.length ?? 0);
            if (used + t > budget && out.length)
                break;
            out.unshift(chunks[i]);
            used += t;
        }
        return out;
    }
    async compact(chunks, summarize) {
        if (this.s !== 'summary')
            return chunks;
        const full = chunks.map(c => c.text).join('');
        const sum = await summarize(full);
        return [{ text: sum }];
    }
}
