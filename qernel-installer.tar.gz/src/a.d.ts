import type { GD, SC, Src } from './t.js';
export declare function oai(body: any, key: string, m: string): AsyncGenerator<{
    text: any;
}, void, unknown>;
export declare function fromCb(fn: (d: GD, on: (c: SC) => void, sig: AbortSignal) => void | AsyncGenerator<SC>): Src;
