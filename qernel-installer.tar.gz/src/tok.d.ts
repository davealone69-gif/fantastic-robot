export interface Tokenizer {
    encode(text: string): number[];
    decode(ids: number[]): string;
    count(text: string): number;
}
export declare class BasicTokenizer implements Tokenizer {
    encode(text: string): number[];
    decode(ids: number[]): string;
    count(text: string): number;
}
export declare function estimateTokens(text: string, tok: Tokenizer): number;
export declare class TiktokenTokenizer implements Tokenizer {
    private enc;
    constructor(model?: string);
    encode(text: string): number[];
    decode(ids: number[]): string;
    count(text: string): number;
}
