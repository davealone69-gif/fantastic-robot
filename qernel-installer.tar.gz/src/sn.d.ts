import type { QRuntime } from './q.js';
export interface Snap {
    v: number;
    nodeId: string;
    ts: number;
    history: any[];
    dave: {
        st: any;
    };
}
export declare class SN {
    static from(rt: QRuntime, opt?: {
        includeTele?: boolean;
    }): Snap;
    static to(s: Snap): any;
}
