import type { Hooks } from './d.js';
import { QO, QM } from './l.js';
export interface TEv {
    type: string;
    ts: number;
    nid: string;
    payload: Record<string, any>;
    flag?: number;
    phrase?: string;
    len?: number;
    traceId?: string;
    sessionId?: string;
}
export declare class DB {
    private orch?;
    private mem?;
    private q;
    private run;
    private th?;
    private nid;
    private onUsage?;
    private onMetric?;
    constructor(orch?: QO, mem?: QM, nid?: string);
    start(): void;
    stop(_t?: number): void;
    feed(ev: TEv): void;
    setCallbacks(onUsage?: (p: number, c: number) => void, onMetric?: (ns: any, latMs: number, err?: boolean) => void): void;
    snapshot(): {
        queue: number;
        memEntries: number;
    };
    private _wk;
    private _pr;
}
export declare function mkTL(o?: {
    nid?: string;
    s?: (ev: TEv) => void;
}): Hooks;
