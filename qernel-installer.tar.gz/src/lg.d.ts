export type Level = 'debug' | 'info' | 'warn' | 'error';
export interface LogEntry {
    ts: number;
    level: Level;
    msg: string;
    fields?: Record<string, any>;
}
export interface Logger {
    log(level: Level, msg: string, fields?: Record<string, any>): void;
    debug(msg: string, fields?: Record<string, any>): void;
    info(msg: string, fields?: Record<string, any>): void;
    warn(msg: string, fields?: Record<string, any>): void;
    error(msg: string, fields?: Record<string, any>): void;
}
export declare class ConsoleLogger implements Logger {
    private prefix;
    constructor(prefix?: string);
    log(level: Level, msg: string, fields?: Record<string, any>): void;
    debug(msg: string, fields?: Record<string, any>): void;
    info(msg: string, fields?: Record<string, any>): void;
    warn(msg: string, fields?: Record<string, any>): void;
    error(msg: string, fields?: Record<string, any>): void;
}
export declare class BufferLogger implements Logger {
    private max;
    private buf;
    constructor(max?: number);
    log(level: Level, msg: string, fields?: Record<string, any>): void;
    debug(msg: string, fields?: Record<string, any>): void;
    info(msg: string, fields?: Record<string, any>): void;
    warn(msg: string, fields?: Record<string, any>): void;
    error(msg: string, fields?: Record<string, any>): void;
    dump(): LogEntry[];
}
