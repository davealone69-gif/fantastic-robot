export const now = () => Date.now();
export const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
export const sha3 = async (s) => {
    const buf = new TextEncoder().encode(s);
    const h = await crypto.subtle.digest('SHA-256', buf);
    return Array.from(new Uint8Array(h)).map(b => b.toString(16).padStart(2, '0')).join('');
};
export const splitPara = (t) => t.split(/\n\s*\n/).map(s => s.trim()).filter(Boolean);
export const splitSen = (t) => t.split(/[.!?]+/).map(s => s.trim()).filter(Boolean);
export const splitWor = (t) => t.split(/\s+/).filter(Boolean);
export const esc = (s) => JSON.stringify(s);
export const sleep = (ms) => new Promise(r => setTimeout(r, ms));
