export class UC {
    constructor() {
        this.turns = 0;
        this.pTok = 0;
        this.cTok = 0;
        this.cp = 0.00002;
        this.ct = 0.000002;
        this.costEstimate = 0;
    }
    add(p, c) { this.turns++; this.pTok += p; this.cTok += c; this.costEstimate = this.pTok * this.cp + this.cTok * this.ct; }
    get() { return { turns: this.turns, promptTokens: this.pTok, completionTokens: this.cTok, costEstimate: this.costEstimate }; }
    reset() { this.turns = 0; this.pTok = 0; this.cTok = 0; this.costEstimate = 0; }
}
