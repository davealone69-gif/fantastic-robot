import type { BK } from './t.js';
import { TR } from './tr.js';
export interface MCPOpt {
    command: string;
    args?: string[];
    cwd?: string;
    timeoutMs?: number;
}
export declare class MCPTransport {
    private opt;
    private tr;
    constructor(opt?: MCPOpt);
    connect(): Promise<void>;
    registry(): TR;
    static toBk(tr: TR): BK;
}
