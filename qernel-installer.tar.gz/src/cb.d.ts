type State = 'closed' | 'open' | 'halfOpen';
export interface CBOpt {
    failAfter?: number;
    recovMs?: number;
    onStateChange?: (from: State, to: State) => void;
}
export declare class CB {
    private failAfter;
    private recovMs;
    private onState;
    private state;
    private fails;
    private openedAt;
    private fn?;
    private fb?;
    constructor(failAfter?: number, recovMs?: number, onState?: (from: State, to: State) => void);
    exec<T>(fn: () => Promise<T>, fallback?: () => Promise<T>): Promise<T>;
    private setState;
    isOpen(): boolean;
    reset(): void;
}
export {};
