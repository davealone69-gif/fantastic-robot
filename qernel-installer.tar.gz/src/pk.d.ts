export interface Plugin {
    name: string;
    type: 'backend' | 'tool' | 'hook' | 'processor';
    impl: any;
    meta?: any;
}
export interface PluginManifest {
    name: string;
    type: string;
    entry: string;
    provides?: string[];
    depends?: string[];
    config?: any;
}
export declare class PK {
    private m;
    register(p: Plugin): void;
    unregister(name: string): void;
    get(name: string): Plugin | undefined;
    all(): Plugin[];
    byType(t: Plugin['type']): Plugin[];
    loadFrom(dir: string): Promise<void>;
}
