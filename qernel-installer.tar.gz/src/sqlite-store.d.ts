import { Store } from './store.js';
export declare class SQLiteStore implements Store {
    private path;
    private db;
    constructor(path: string);
    init(): Promise<void>;
    get(k: string): Promise<[any, boolean]>;
    put(k: string, v: any, tags?: string[], ttl?: number): Promise<void>;
    del(k: string): Promise<boolean>;
    byTag(tag: string): Promise<[string, any][]>;
    clear(): Promise<void>;
    stats(): Promise<{
        size: any;
    }>;
    close(): Promise<void>;
}
