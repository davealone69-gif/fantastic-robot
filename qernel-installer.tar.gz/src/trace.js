let root = '0'.repeat(12);
let sid = Math.random().toString(36).slice(2, 14);
export function rootTrace() { return root; }
export function setRootTrace(t) { root = t; }
export function sessionId() { return sid; }
export function resetTrace() { sid = Math.random().toString(36).slice(2, 14); }
export function traceSpan(t, n) { return `${root}.${sid}.${t}.${n}`; }
