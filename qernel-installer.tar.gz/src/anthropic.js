export class AnthropicBk {
    constructor(key, model = 'claude-3-5-haiku-20241022', base = 'https://api.anthropic.com') {
        this.key = key;
        this.model = model;
        this.base = base;
    }
    async *stream(u, _h, i, _t, _m, _sig) {
        const r = await fetch(`${this.base}/v1/messages`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': this.key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }, body: JSON.stringify({ model: this.model, max_tokens: 1024, system: i, messages: [{ role: 'user', content: u }], stream: true }) });
        if (!r.ok) {
            yield { type: 'error', data: { message: `Anthropic ${r.status}` } };
            return;
        }
        const rd = r.body?.getReader();
        const dc = new TextDecoder();
        let buf = '';
        while (true) {
            const { value, done } = await rd.read();
            if (done)
                break;
            buf += dc.decode(value, { stream: true });
            const lines = buf.split('\n');
            buf = lines.pop() ?? '';
            for (const ln of lines) {
                const s = ln.trim();
                if (!s.startsWith('data: '))
                    continue;
                try {
                    const j = JSON.parse(s.slice(6));
                    const d = j.delta?.text ?? '';
                    if (d)
                        yield { type: 'text.delta', data: { delta: d } };
                }
                catch { }
            }
        }
        yield { type: 'done', data: { cognitive_state: null, stats: {} } };
    }
}
