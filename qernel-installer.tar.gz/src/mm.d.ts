import type { SC } from './t.js';
export type MMKind = 'text' | 'image' | 'audio' | 'tool_result';
export interface MMExt {
    kind: MMKind;
    mime?: string;
    data: string | Record<string, any>;
}
export declare function toSC(ext: MMExt): SC;
export declare function classify(c: SC): MMKind;
