export interface SnapDelta {
    path: string;
    from: any;
    to: any;
}
export type MergeStrategy = 'last-write-wins' | 'append-history';
export declare class DM {
    static diff(a: any, b: any, prefix?: string): SnapDelta[];
    static merge(a: any, b: any, strategy?: MergeStrategy): any;
}
