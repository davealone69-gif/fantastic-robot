import type { GD, SC, Src } from './t.js';
export type { GD, SC };
export declare class HE {
    h: any;
    on<K extends keyof any>(n: K, fn: (...a: any[]) => void): this;
    em<K extends keyof any>(n: K, ...a: any[]): void;
    raw(): any;
}
export interface Hooks {
    onPreReq?: (d: GD) => GD | void;
    onChunk?: (c: SC, a: string) => SC | void;
    onEdit?: (f: number, p: string) => void;
    onSignal?: (s: any) => void;
    onStop?: (r: 'edit' | 'signal') => void;
    onResume?: (d: GD) => void;
    onFinish?: (m: string) => void;
    onError?: (e: Error) => void;
}
export declare class M {
    s: any;
    st: any;
    constructor(s: any, st?: any);
    set(t: string): void;
    poll(t: string): {
        trig: boolean;
        flag?: number;
        signal?: number;
    };
    reset(): void;
}
export declare function ae(res: any, m: any, _cl: number): any;
export declare function sm(d: GD, c: any): GD;
export declare function sg(st: any): void;
export declare class AC {
    static correct(e: any, msg: string): {
        msg: string;
        flag: number;
        phrase: string;
    };
}
export declare class CR {
    static armed(e: any): boolean;
    static enabled(e: any): boolean;
    static prime(e: any): void;
}
export declare class QT {
    static tier(e: any): any;
    static setTier(e: any, t: number): void;
    static err(e: any): any;
}
export interface GO {
    data: GD;
    isCon?: boolean;
    conMsg?: string;
}
export interface GR {
    msg: string;
    con: string;
    chk: string;
}
export declare class DE {
    s: any;
    t: any;
    m: M;
    h: HE;
    c: any;
    constructor(o: {
        s: any;
        t: any;
        st?: any;
        h?: Hooks;
        trigger?: string;
    });
    ge(src: Src, o: GO): Promise<GR>;
}
export declare class DP {
    e: DE;
    constructor(o?: {
        s?: Partial<any>;
        t?: Partial<any>;
        h?: Hooks;
        trigger?: string;
    });
    get ac(): typeof AC;
    get cr(): typeof CR;
    get qt(): typeof QT;
    ge(src: Src, o: GO): Promise<GR>;
    co(m: string): {
        msg: string;
        flag: number;
        phrase: string;
    };
    ap(p: Partial<any>): void;
    rs(): void;
}
