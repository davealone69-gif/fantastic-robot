export class MX {
    constructor(opts = {}) {
        this.opts = opts;
        this.samples = [];
        this.calls = 0;
        this.errs = 0;
        this.lat = 0;
        this.opts.maxSamples = opts.maxSamples ?? 1000;
    }
    record(ns, latMs, err = false) { this.calls++; this.lat += latMs; if (err)
        this.errs++; this.samples.push({ ts: Date.now(), nodes: ns, calls: this.calls, errs: this.errs, latMs: this.lat }); if (this.samples.length > (this.opts.maxSamples ?? 1000))
        this.samples.shift(); }
    snapshot() { return { calls: this.calls, errs: this.errs, avgLatMs: this.calls ? this.lat / this.calls : 0, samples: this.samples.slice(-20) }; }
    prometheus() {
        const s = this.snapshot();
        return [
            `# HELP qernel_calls_total total calls`,
            `# TYPE qernel_calls_total counter`,
            `qernel_calls_total ${s.calls}`,
            `# HELP qernel_errors_total total errors`,
            `# TYPE qernel_errors_total counter`,
            `qernel_errors_total ${s.errs}`,
            `# HELP qernel_latency_ms_avg average latency ms`,
            `# TYPE qernel_latency_ms_avg gauge`,
            `qernel_latency_ms_avg ${s.avgLatMs.toFixed(3)}`,
        ].join('\n');
    }
}
