import type { BK, SE } from './t.js';
export declare class PL {
    private bks;
    private cur;
    private rt;
    private rl;
    add(bk: BK): this;
    rm(bk: BK): void;
    len(): number;
    next(): BK;
    fail(): void;
    stream(u: string, h: any[], i: string, t: any[], m?: number, sig?: AbortSignal): AsyncGenerator<SE>;
}
