import type { SC } from './t.js';
export type CXS = 'sliding' | 'summary' | 'off';
export declare class CX {
    private s;
    constructor(strategy?: CXS, _maxTokens?: number);
    estimate(chunks: SC[]): number;
    fit(chunks: SC[], budget: number): SC[];
    compact(chunks: SC[], summarize: (text: string) => string | Promise<string>): Promise<SC[]>;
}
