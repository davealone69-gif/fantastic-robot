export class TDr {
    constructor(tr) {
        this.tr = tr;
    }
    wrap(src) {
        return (d, sig) => this.dispatch(src(d, sig), sig);
    }
    async *dispatch(gen, sig) {
        for await (const c of gen) {
            yield c;
            const raw = c.raw;
            if (raw?.type === 'tool.call') {
                const payload = raw;
                const name = payload.data?.name ?? payload.data?.tool_name ?? 'unknown';
                const args = payload.data?.args ?? payload.data?.arguments ?? {};
                const result = await this.tr.run(name, args, { signal: sig });
                yield { text: '', raw: { type: 'tool.result', data: { name, result } } };
            }
        }
    }
}
export function normalizeSE(ev) {
    if (ev.type === 'text.delta')
        return { text: ev.data.delta ?? '', raw: ev };
    if (ev.type === 'tool.call')
        return { text: '', raw: ev };
    if (ev.type === 'done')
        return { text: '', raw: ev };
    if (ev.type === 'error')
        return { text: '', raw: ev };
    if (ev.type === 'backend.status')
        return { text: '', raw: ev };
    return { text: '', raw: ev };
}
