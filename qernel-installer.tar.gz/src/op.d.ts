export declare class OP {
    static json<T = any>(txt: string): T;
    static regex(txt: string, pattern: string): string | null;
    static field(txt: string, field: string): string | null;
    static validate(txt: string, schema: {
        type: 'object';
        required?: string[];
        properties?: Record<string, {
            type: string;
        }>;
    }): boolean;
}
