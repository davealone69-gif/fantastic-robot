export class RL {
    constructor(_bus, opt = {}) {
        this.tpm = 100000;
        this.refillMs = 1000;
        this.tokens = this.tpm;
        this.last = Date.now();
        this.tpm = opt.tpm ?? 100000;
        this.refillMs = opt.refillMs ?? 1000;
    }
    allow(tokens = 1000) {
        const now = Date.now();
        const dt = now - this.last;
        this.last = now;
        this.tokens = Math.min(this.tpm, this.tokens + (dt / this.refillMs) * this.tpm);
        if (this.tokens < tokens)
            return false;
        this.tokens -= tokens;
        return true;
    }
}
export function perBackendRL(_bks, opts) { return [new RL({ emit: () => { } }, opts)]; }
