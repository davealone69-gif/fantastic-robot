import type { BK, NM } from './t.js';
export interface HCProbe {
    ok: boolean;
    latMs: number;
    err?: string;
    ts: number;
}
export interface HCOpt {
    intervalMs?: number;
    timeoutMs?: number;
    maxConsec?: number;
}
export declare class HC {
    private fails;
    constructor(_opt?: HCOpt);
    probe(name: string, bk: Pick<BK, 'stream'>): Promise<HCProbe>;
    shouldEvict(name: string): boolean;
    record(name: string, ok: boolean): void;
}
export declare function toNM(name: string, p: HCProbe): NM;
