export interface Usage {
    turns: number;
    promptTokens: number;
    completionTokens: number;
    costEstimate: number;
}
export declare class UC {
    private turns;
    private pTok;
    private cTok;
    private cp;
    private ct;
    private costEstimate;
    add(p: number, c: number): void;
    get(): Usage;
    reset(): void;
}
