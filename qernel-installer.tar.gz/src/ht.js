import { createRequire } from 'module';
const req = createRequire(import.meta.url);
export class HT {
    constructor(bk, port = 3000) {
        this.bk = bk;
        this.port = port;
    }
    start() {
        const bk = this.bk;
        const http = req('http');
        const srv = http.createServer(async (req, res) => {
            if (req.url === '/v1/chat' && req.method === 'POST') {
                let body = '';
                req.on('data', (d) => body += d.toString());
                req.on('end', async () => {
                    try {
                        const j = JSON.parse(body);
                        const msgs = j.messages ?? [];
                        const sys = msgs.find((m) => m.role === 'system')?.content ?? '';
                        const hist = msgs.filter((m) => m.role !== 'system' && m.role !== 'user').slice(-10);
                        const u = msgs.filter((m) => m.role === 'user').pop()?.content ?? '';
                        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
                        for await (const ev of bk.stream(u, hist, sys, [], j.max_tokens)) {
                            res.write(`data: ${JSON.stringify(ev)}\n\n`);
                        }
                        res.write('data: [DONE]\n\n');
                        res.end();
                    }
                    catch {
                        res.writeHead(400);
                        res.end();
                    }
                });
            }
            else {
                res.writeHead(404);
                res.end();
            }
        });
        srv.listen(this.port);
        return srv;
    }
}
