function hash(s) { let h = 5381; for (let i = 0; i < s.length; i++)
    h = ((h << 5) + h + s.charCodeAt(i)) | 0; return h.toString(36); }
export class Cache {
    constructor(opts = {}) {
        this.opts = opts;
        this.m = new Map();
        this.opts.ttlMs = opts.ttlMs ?? 60000;
        this.opts.maxEntries = opts.maxEntries ?? 1024;
        this.opts.maxPromptBytes = opts.maxPromptBytes ?? 4096;
    }
    key(g) { const base = JSON.stringify({ p: g.prompt?.slice(0, 1024), t: g.temperature, k: g.top_k }); return hash(base); }
    get(g) { const e = this.m.get(this.key(g)); if (!e)
        return null; if (Date.now() > e.exp) {
        this.m.delete(this.key(g));
        return null;
    } return e.v; }
    set(g, v) {
        if ((g.prompt?.length ?? 0) > (this.opts.maxPromptBytes ?? 4096))
            return false;
        const k = this.key(g);
        this.m.set(k, { v, exp: Date.now() + (this.opts.ttlMs ?? 60000) });
        if (this.m.size > (this.opts.maxEntries ?? 1024)) {
            const first = this.m.keys().next().value;
            if (first)
                this.m.delete(first);
        }
        return true;
    }
    clear() { this.m.clear(); }
}
export async function* cachedStream(bk, g, sig, cache) {
    const hit = cache.get(g);
    if (hit) {
        for (const c of hit)
            yield c;
        return;
    }
    const buf = [];
    for await (const c of bk.stream(g.prompt ?? '', [], '', [], undefined, sig)) {
        buf.push(c);
        yield c;
    }
    cache.set(g, buf);
}
