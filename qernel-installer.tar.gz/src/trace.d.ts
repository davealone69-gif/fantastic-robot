export declare function rootTrace(): string;
export declare function setRootTrace(t: string): void;
export declare function sessionId(): string;
export declare function resetTrace(): void;
export declare function traceSpan(t: string, n: string): string;
