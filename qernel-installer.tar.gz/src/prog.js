export class Prog {
    constructor(onUpdate) {
        this.onUpdate = onUpdate;
        this.emitted = 0;
    }
    update(c, total) { this.emitted += (c.text?.length ?? 0); this.total = total; this.onUpdate?.({ emitted: this.emitted, total: this.total, pct: this.total ? this.emitted / this.total : undefined }); }
    reset() { this.emitted = 0; this.total = undefined; }
    snapshot() { return { emitted: this.emitted, total: this.total, pct: this.total ? this.emitted / this.total : undefined }; }
}
export async function* withProgress(input, progress, total) {
    for await (const c of input) {
        progress.update(c, total);
        yield c;
    }
}
