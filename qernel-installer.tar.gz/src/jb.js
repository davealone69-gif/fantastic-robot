export class JB {
    constructor(concurrency = 2) {
        this.concurrency = concurrency;
        this.jobs = [];
        this.q = [];
        this.running = 0;
    }
    schedule(fn, opts = {}) {
        const id = opts.id ?? Math.random().toString(36).slice(2);
        const job = { id, fn, retries: 0, maxRetries: opts.maxRetries ?? 3, backoffMs: opts.backoffMs ?? 1000, state: 'queued' };
        this.q.push(job);
        this.drain();
        return job;
    }
    async drain() {
        while (this.q.length && this.running < this.concurrency) {
            const job = this.q.shift();
            this.running++;
            job.state = 'running';
            this.jobs.push(job);
            (async () => {
                try {
                    await job.fn();
                    job.state = 'done';
                }
                catch (e) {
                    job.state = 'failed';
                    job.err = e.message;
                    if (job.retries++ < job.maxRetries) {
                        this.q.push(job);
                        await new Promise(r => setTimeout(r, job.backoffMs * Math.pow(2, job.retries)));
                    }
                }
                finally {
                    this.running--;
                    this.drain();
                }
            })();
        }
    }
    all() { return this.jobs; }
    summary() { return { total: this.jobs.length, queued: this.q.length, running: this.running, done: this.jobs.filter(j => j.state === 'done').length, failed: this.jobs.filter(j => j.state === 'failed').length }; }
}
