import type { BK, SE, NM } from './t.js';
export interface RTOpt {
    maxRetries?: number;
    baseMs?: number;
    timeoutMs?: number;
}
export declare class RT {
    private opts;
    constructor(opts?: RTOpt);
    exec(bks: Pick<BK, 'stream'>[], fn: (bk: Pick<BK, 'stream'>) => AsyncGenerator<SE>, fallback?: () => AsyncGenerator<SE>): AsyncGenerator<SE>;
    static select(bks: BMeta[]): BMeta[];
}
export interface BMeta {
    bk: BK;
    meta: NM;
    score: number;
}
