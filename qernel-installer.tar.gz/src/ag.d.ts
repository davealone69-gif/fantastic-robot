import type { SC } from './t.js';
export type ReducerFn<T> = (acc: T, c: SC, idx: number) => T | Promise<T>;
export declare class AG<T> {
    private init;
    private fn;
    constructor(init: T, fn: ReducerFn<T>);
    run(chunks: SC[]): Promise<T>;
    runGen(input: AsyncGenerator<SC>): AsyncGenerator<T>;
}
export declare const textJoin: (a: string, c: SC) => string;
export declare const tokenCount: (a: number, c: SC) => number;
export declare const latSampler: (arr: number[], _c: SC, _idx: number) => number[];
