export function toSC(ext) {
    if (ext.kind === 'text')
        return { text: ext.data };
    return { text: '', raw: ext };
}
export function classify(c) {
    const t = c.text ?? '';
    const r = c.raw;
    if (typeof r === 'object' && r !== null && r.mime)
        return r.kind ?? 'tool_result';
    if (t.startsWith('data:'))
        return 'image';
    return 'text';
}
