import { EventEmitter } from 'events';
import type { BK } from './t.js';
export declare const TD: 'text.delta';
export declare const TC: 'tool.call';
export declare const DN: 'done';
export declare const ER: 'error';
export declare const BS: 'backend.status';
export declare class OB extends EventEmitter implements BK {
    base: string;
    model: string;
    key: string;
    constructor(base: string, model: string, key: string);
    stream(u: string, h: any[], i: string, t: any[], m?: number, _sig?: AbortSignal): AsyncGenerator<{
        type: "error";
        data: {
            message: string;
            delta?: undefined;
            cognitive_state?: undefined;
            stats?: undefined;
        };
    } | {
        type: "text.delta";
        data: {
            message?: undefined;
            delta: any;
            cognitive_state?: undefined;
            stats?: undefined;
        };
    } | {
        type: "done";
        data: {
            message?: undefined;
            delta?: undefined;
            cognitive_state: null;
            stats: {
                prompt_eval_count: any;
                eval_count: any;
            };
        };
    }, void, unknown>;
}
export declare class KB extends EventEmitter implements BK {
    base: string;
    key: string;
    to: number;
    constructor(base: string, key: string, to?: number);
    stream(u: string, _h: any[], i: string, _t: any[], m?: number, _sig?: AbortSignal): AsyncGenerator<{
        type: "error";
        data: {
            delta?: undefined;
            cognitive_state?: undefined;
            stats?: undefined;
            message: string;
        };
    } | {
        type: "text.delta";
        data: {
            message?: undefined;
            cognitive_state?: undefined;
            stats?: undefined;
            delta: any;
        };
    } | {
        type: "done";
        data: {
            message?: undefined;
            delta?: undefined;
            cognitive_state: null;
            stats: {};
        };
    }, void, unknown>;
}
export declare class CB implements BK {
    private cmd;
    private args;
    constructor(cmd?: string, args?: string[]);
    stream(u: string, _h: any[], i: string, _t: any[], _m?: number, _sig?: AbortSignal): AsyncGenerator<{
        type: "text.delta";
        data: {
            cognitive_state?: undefined;
            stats?: undefined;
            delta: any;
        };
    } | {
        type: "done";
        data: {
            delta?: undefined;
            cognitive_state: null;
            stats: {};
        };
    }, void, unknown>;
}
export declare function mkB(cfg: {
    type: string;
    [k: string]: any;
}): BK;
