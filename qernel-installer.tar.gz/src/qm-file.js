import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { dirname } from 'path';
import { QM } from './l.js';
export class QMFile extends QM {
    constructor(path) { super(); this.path = path; if (existsSync(path)) {
        try {
            const data = JSON.parse(readFileSync(path, 'utf8'));
            for (const [k, v] of Object.entries(data))
                this.put(k, v.v);
        }
        catch { }
    } }
    put(k, v, tags, et) { super.put(k, v, tags, et); this.persist(); }
    del(k) { const r = super.del(k); this.persist(); return r; }
    clr() { super.clr(); this.persist(); }
    persist() { try {
        const dir = dirname(this.path);
        if (!existsSync(dir))
            mkdirSync(dir, { recursive: true });
        const obj = {};
        for (const [k, entry] of this.d.entries())
            obj[k] = entry;
        writeFileSync(this.path, JSON.stringify(obj));
    }
    catch { } }
}
