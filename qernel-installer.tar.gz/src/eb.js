export class EB {
    constructor() {
        this.m = new Map();
    }
    on(name, fn) {
        let s = this.m.get(name);
        if (!s) {
            s = new Set();
            this.m.set(name, s);
        }
        s.add(fn);
        return () => this.off(name, fn);
    }
    off(name, fn) { this.m.get(name)?.delete(fn); }
    emit(name, ...a) { for (const [k, fns] of this.m) {
        if (this.match(k, name) || k === name)
            fns.forEach(fn => { try {
                fn(...a);
            }
            catch { } });
    } }
    join(name2) { return (n) => `${n}:${name2}`; }
    match(pattern, name) {
        if (!pattern.includes('*'))
            return false;
        const regex = new RegExp('^' + pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$');
        return regex.test(name);
    }
}
