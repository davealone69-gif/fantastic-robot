export class ConsoleLogger {
    constructor(prefix = 'qernel') {
        this.prefix = prefix;
    }
    log(level, msg, fields) { console[level](`[${this.prefix}] ${msg}`, fields ?? {}); }
    debug(msg, fields) { this.log('debug', msg, fields); }
    info(msg, fields) { this.log('info', msg, fields); }
    warn(msg, fields) { this.log('warn', msg, fields); }
    error(msg, fields) { this.log('error', msg, fields); }
}
export class BufferLogger {
    constructor(max = 1000) {
        this.max = max;
        this.buf = [];
    }
    log(level, msg, fields) { this.buf.push({ ts: Date.now(), level, msg, fields }); if (this.buf.length > this.max)
        this.buf.shift(); }
    debug(msg, fields) { this.log('debug', msg, fields); }
    info(msg, fields) { this.log('info', msg, fields); }
    warn(msg, fields) { this.log('warn', msg, fields); }
    error(msg, fields) { this.log('error', msg, fields); }
    dump() { return this.buf.slice(); }
}
