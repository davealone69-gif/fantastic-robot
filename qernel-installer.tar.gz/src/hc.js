export class HC {
    constructor(_opt = {}) {
        this.fails = new Map();
    }
    async probe(name, bk) {
        const t0 = Date.now();
        try {
            const sig = new AbortController();
            const t = setTimeout(() => sig.abort(), 5000);
            const gen = bk.stream('', [], '', [], 1, sig.signal);
            let ok = false;
            for await (const c of gen) {
                if (c.type === 'text.delta')
                    ok = true;
                break;
            }
            clearTimeout(t);
            this.fails.set(name, 0);
            return { ok, latMs: Date.now() - t0, ts: Date.now() };
        }
        catch (e) {
            const c = (this.fails.get(name) ?? 0) + 1;
            this.fails.set(name, c);
            return { ok: false, latMs: Date.now() - t0, err: e.message, ts: Date.now() };
        }
    }
    shouldEvict(name) { return (this.fails.get(name) ?? 0) >= 3; }
    record(name, ok) { if (ok)
        this.fails.set(name, 0);
    else {
        const c = (this.fails.get(name) ?? 0) + 1;
        this.fails.set(name, c);
    } }
}
export function toNM(name, p) { return { id: name, load: p.ok ? 0 : 1, lat: p.ok ? p.latMs : 99999, err: p.ok ? 0 : 1, thr: p.ok ? 10 : 0, ent: 0, lu: p.ts }; }
