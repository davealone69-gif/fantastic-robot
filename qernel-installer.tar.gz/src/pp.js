export class PP {
    constructor() {
        this.fns = [];
    }
    use(fn) { this.fns.push(fn); return this; }
    async run(chunks) {
        const out = [];
        for (let i = 0; i < chunks.length; i++) {
            let c = { ...chunks[i] };
            for (const fn of this.fns) {
                c = await fn(c, i);
                if (!c)
                    break;
            }
            if (c)
                out.push(c);
        }
        return out;
    }
    async *runGen(input) {
        let idx = 0;
        for await (const c of input) {
            let out = { ...c };
            for (const fn of this.fns) {
                out = await fn(out, idx++);
                if (!out)
                    break;
            }
            if (out)
                yield out;
        }
    }
}
